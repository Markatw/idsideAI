# Sprint 24 — Checklist (protocol v2)

- [x] 24.1 — Scaffold & baseline
- [ ] 24.2 — Login/Reset polish
- [ ] 24.3 — Dashboard polish
- [ ] 24.4 — Graphs UI tooltips
- [ ] 24.5 — Dark mode toggle
- [ ] 24.6 — i18n hooks
- [ ] 24.7 — A11y overlay widget
- [ ] 24.8 — Error pages polish
- [ ] 24.9 — Pre-wrap stabilization
- [ ] 24.10 — Deep Audit Pack + Wrap
