# Sprint 28 Checklist

1. Scaffold 28 (VERSION bump, log).
2. Branding polish (logos, favicons).
3. Final investor pack integration (PDF, deck).
4. Stripe live integration (un-stub).
5. Referral engine enable.
6. Enterprise feature flag toggle.
7. Security pen-test scan.
8. Final i18n update.
9. Pre-wrap stabilization.
10. Deep Audit + FINAL Wrap (Master release).
