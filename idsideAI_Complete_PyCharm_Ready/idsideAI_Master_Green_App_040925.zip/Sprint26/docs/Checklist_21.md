# Sprint 21 — Checklist (protocol v2)

- [x] **21.1** — Create Sprint 21 scaffold (docs, QC seed, version bump)  
  - Status: DONE  
  - Notes: Baseline S20.16 archive; protocol v2
- [ ] **21.2** — Decision Graphs: export & rendering polish  
  - Status: TODO  
  - Notes: 
- [ ] **21.3** — Turbo quality monitoring: refine failure detection + benchmarks  
  - Status: TODO  
  - Notes: 
- [ ] **21.4** — Provider adapters: multi-provider readiness pass  
  - Status: TODO  
  - Notes: 
- [ ] **21.5** — Address any critical-file anomalies from S20 QC  
  - Status: TODO  
  - Notes: 
- [ ] **21.6** — Checkpoint wrap for Sprint 21 (v2)  
  - Status: TODO  
  - Notes: 
