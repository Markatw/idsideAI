
- S19.1: Themed Chat page (message bubbles, empty state, input bar).
- S19.2: Themed docs editor shell + toolbar (sticky toolbar, editor content, status bar).
- S19.3: Themed Presence page (rows, avatars, status pill, actions layout).
- S19.4: Themed activity timeline (rail, items, timestamp, summary, details, badge).
- S19.6: Polished Help index (search bar, categories, list grid, breadcrumbs, hover).
- S19.7: Added contextual help styles (hover bubble .help-tip, .callout-info/.callout-warn, .help-inline).
- S19.8: Added status toasts system (.toasts/.toast) and global states (.loading/.empty/.error).
- S19.9: Themed Export page (controls, summary, responsive table, hover, export toast hook).
