
- **Stress test page**: temporarily route App to `StressTest` to evaluate 10k nodes.
