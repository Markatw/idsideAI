
## Quick wiring with Make

```bash
make deploy-secrets-and-patch NS=idecide
```
