# Build Report v7

Full integrated app, PyCharm-ready.
