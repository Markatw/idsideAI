# idsideAI v7 MASTER

This is the integrated, PyCharm-ready release.
