Sample SDL: examples/demo_decision_model.yaml
Run the server (python run.py) then paste the YAML into the UI at http://127.0.0.1:8000
