#!/usr/bin/env python3
"""
idsideAIfinal - Enhanced Run Script for PyCharm
==============================================

This script provides an enhanced way to run the idsideAIfinal FastAPI application
with proper error handling, dependency checking, and development features.

Usage:
    python run.py              # Start the application
    python run.py --check      # Check setup and dependencies
    python run.py --help       # Show help information
"""

import sys
import os
import subprocess
import argparse
import logging
from pathlib import Path

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler('idsideAIfinal.log', mode='a')
    ]
)
logger = logging.getLogger(__name__)

def check_python_version():
    """Check if Python version is compatible."""
    if sys.version_info < (3, 8):
        logger.error("Python 3.8 or higher is required")
        return False
    logger.info(f"Python version: {sys.version}")
    return True

def check_dependencies():
    """Check if all required dependencies are installed."""
    try:
        import fastapi
        import uvicorn
        import sqlmodel
        import jinja2
        import httpx
        logger.info("All core dependencies are available")
        return True
    except ImportError as e:
        logger.error(f"Missing dependency: {e}")
        logger.info("Run: pip install -r requirements.txt")
        return False

def check_application():
    """Check if the application can be imported."""
    try:
        from app.main import app
        logger.info("Application imported successfully")
        return True
    except Exception as e:
        logger.error(f"Failed to import application: {e}")
        return False

def run_setup_check():
    """Run comprehensive setup check."""
    logger.info("=== idsideAIfinal Setup Check ===")
    
    checks = [
        ("Python Version", check_python_version),
        ("Dependencies", check_dependencies),
        ("Application Import", check_application)
    ]
    
    all_passed = True
    for name, check_func in checks:
        logger.info(f"Checking {name}...")
        if check_func():
            logger.info(f"✅ {name}: PASSED")
        else:
            logger.error(f"❌ {name}: FAILED")
            all_passed = False
    
    if all_passed:
        logger.info("🎉 All checks passed! Application is ready to run.")
        return True
    else:
        logger.error("❌ Some checks failed. Please fix the issues above.")
        return False

def start_application():
    """Start the FastAPI application with uvicorn."""
    logger.info("=== Starting idsideAIfinal Application ===")
    
    # Check if setup is valid
    if not run_setup_check():
        logger.error("Setup check failed. Cannot start application.")
        return False
    
    try:
        logger.info("Starting uvicorn server...")
        logger.info("Application will be available at: http://localhost:8000")
        logger.info("API documentation: http://localhost:8000/docs")
        logger.info("Press Ctrl+C to stop the server")
        
        # Start uvicorn
        subprocess.run([
            sys.executable, "-m", "uvicorn",
            "app.main:app",
            "--host", "0.0.0.0",
            "--port", "8000",
            "--reload",
            "--log-level", "info"
        ], check=True)
        
    except KeyboardInterrupt:
        logger.info("Application stopped by user")
        return True
    except subprocess.CalledProcessError as e:
        logger.error(f"Failed to start application: {e}")
        return False
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        return False

def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description="idsideAIfinal - FastAPI Application Runner",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
    python run.py              # Start the application
    python run.py --check      # Check setup and dependencies
    python run.py --help       # Show this help message

For more information, visit the project documentation.
        """
    )
    
    parser.add_argument(
        "--check",
        action="store_true",
        help="Check setup and dependencies without starting the application"
    )
    
    args = parser.parse_args()
    
    try:
        if args.check:
            success = run_setup_check()
            sys.exit(0 if success else 1)
        else:
            success = start_application()
            sys.exit(0 if success else 1)
            
    except Exception as e:
        logger.error(f"Fatal error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()

