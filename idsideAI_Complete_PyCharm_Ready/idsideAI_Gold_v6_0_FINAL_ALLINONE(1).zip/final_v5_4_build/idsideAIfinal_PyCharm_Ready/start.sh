
#!/usr/bin/env bash
set -e
gunicorn -k uvicorn.workers.UvicornWorker app.main:app --timeout 120 --workers 2
