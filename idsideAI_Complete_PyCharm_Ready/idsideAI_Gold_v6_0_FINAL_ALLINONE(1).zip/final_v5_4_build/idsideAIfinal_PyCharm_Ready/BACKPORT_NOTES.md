

## Add from Phase 4 (Enterprise Polish) to standalone bundle
- Security headers middleware + cookie hardening + CORS tightening.
- Accessibility tweaks (skip link, landmarks, ARIA); loading skeletons and toast errors.
- Circuit-breaker status endpoint and UI badges.
- Thought Trails keyboard/ARIA enhancements (if the standalone has trails).

## Add from Phase 5 (Security, Logging & QA) to standalone bundle
- Structured JSON logging + request timing logs.
- Analytics event model + `track()` helper; emit on upgrades/top-ups and successful asks.
- Basic pytest suite and security header tests.


## Phase 6 — Back-port items for standalone idsideAITurbo
- ProviderTelemetry model; record on ask/quickfix/compare.
- Benchmark endpoints: `/api/bench/run`, `/api/bench/recommend` (or equivalent).
- Ask UI badge: "Best for this task now".
- Command Optimiser toggle (pre-flight rewrite).
- Side-by-side comparison mode (`/api/compare`, `/api/compare/choose`).
- LearningLog model and "What I Learned" feed notes.
- Instant Collaboration Drop-In (if the standalone supports threads; otherwise omit).
- Telemetry CSV export `/api/telemetry/export` (include per-user columns if multi-user).
