# idsideAI — FastAPI Scaffold (with idsideAITurbo hooks)

This is a **PyCharm-ready** scaffold for **idsideAI** with integrated **Turbo** premium hooks.

## Quick Start
1. Create a virtual environment (recommended).
2. `pip install -r requirements.txt`
3. `uvicorn app.main:app --reload`  (or run the PyCharm config below)

Then open: http://127.0.0.1:8000

## PyCharm Run Config
- Script path: `uvicorn`
- Parameters: `app.main:app --reload`
- Working directory: project root

## What’s Included
- **Merged Onboarding Screen** (Plan + Workspace + Collaborators + Turbo summary)
- **Branding**: two-tone IDECIDE blues, green ticks, clean layout
- **Routers**: `/`, `/onboarding`, `/dashboard` (stub)
- **Services**: Turbo quality monitoring hooks (stubs), model router (stub)
- **Models**: Pydantic schemas for onboarding form
- **Static/Template**: Jinja2 templates with CSS

## Roadmap (next steps)
- Add authentication & DB (e.g., PostgreSQL + SQLModel/SQLAlchemy)
- Implement Turbo quality metrics & persistence
- Multi-model routing to external providers
- Teams/collabs, shared thought trails, values-based personalization


---

## Multi‑provider AI Routing (NEW)
- Endpoint: `POST /api/ask`
- Body:
```json
{
  "prompt": "Write a 50-word summary about…",
  "task": "long_form",
  "values": {"speed":0.3,"accuracy":0.5,"cost":0.2},
  "preferred": null
}
```
- Selection strategy weighs provider capabilities + your values + task bias.
- **No keys?** Adapters simulate responses in dev, so you can test routing now.
- Add keys via environment variables (examples):
  - `OPENAI_API_KEY`, `ANTHROPIC_API_KEY`, `GEMINI_API_KEY`, `MISTRAL_API_KEY`, `COHERE_API_KEY`,
    `TOGETHER_API_KEY`, `PPLX_API_KEY`, `GROQ_API_KEY`, `XAI_API_KEY`.


---

## Magic-Link Auth (DEV)
- Visit `/auth/signin` and submit your email.
- In development, the magic link is printed to the **server console**. Click it to sign in.
- Session is stored via `SessionMiddleware` (HTTP-only cookie).
- Configure via env:
  - `SECRET_KEY` (required in production)
  - `MAGICLINK_TTL_SECONDS` (default 900s)


---

## Dynamic Model Discovery (NEW)
- Endpoint: `GET /api/providers` — returns providers, availability, and a cached list of models.
- Cache TTL configurable: `MODEL_CACHE_TTL_S` (default 3600s).
- Provider default model configurable with env vars, e.g.:
  - `PROVIDER_DEFAULT_MODEL_OPENAI=gpt-4o-mini`
  - `PROVIDER_DEFAULT_MODEL_GEMINI=gemini-1.5-pro`
  - `PROVIDER_DEFAULT_MODEL_GROQ=llama-3.1-70b`
- Request timeout: `PROVIDER_TIMEOUT_S` (default 18s).


---

## Model-level Selection + Circuit Breaker (NEW)
- `/api/ask` now returns both **provider** and **model** selected.
- Strategy uses live model discovery + env default overrides to pick per-task models.
- **Circuit breaker** auto-skips flaky providers and fails over to the next best.
- Tune via env:
  - `PROVIDER_DEFAULT_MODEL_*` (per provider)
  - `CB_FAIL_THRESHOLD` (default 3)
  - `CB_COOLDOWN_SECONDS` (default 30)


---

## Plan Enforcement (NEW)
- Middleware gates `/api/ask`:
  - **Auth required** (session).
  - **Free plan**: daily quota enforced (default `FREE_DAILY_LIMIT=20`).
  - **Turbo-only actions**: set `requires_turbo: true` in body; returns `402 turbo_required` if Turbo not active.
- Successful `/api/ask` calls increment the daily counter for Free users.

## Live Providers (OpenAI, Gemini, Groq)
- Set env keys: `OPENAI_API_KEY`, `GEMINI_API_KEY`, `GROQ_API_KEY`.
- Retries with exponential backoff; timeouts ~30s.
- Models are **selected dynamically**; default override via `PROVIDER_DEFAULT_MODEL_*`.


---

## Turbo Metrics Ingestion (NEW)
- `/api/ask` measures latency and computes provisional quality scores (accuracy, completeness, adherence, speed).
- Scores are stored per-user in the `Metric` table.
- Dashboard shows averages over your last 20 requests.
- Replace `app/utils/quality.py` with your production rubric when ready.


---

## Collaborators (NEW)
- Visit `/collab` to view members and send email invites.
- Invites generate **magic links** printed to the server console in development.
- Accepting an invite signs the user in (by email) and joins them to the workspace.
- Turbo benefits currently follow the **workspace owner** (MVP).


---

## Shared Quota Mode (NEW)
- Set `WORKSPACE_SHARED_QUOTA=true` to make the Free daily limit **shared** across the workspace.
- Otherwise, quota remains **per user** (default).

## Auto-Invites on Onboarding (NEW)
- Any emails entered in the onboarding "Invite collaborators" field receive a magic-link invite automatically (printed in dev console).


---

## Render Deployment (Pack Included)
- Files: `Procfile`, `render.yaml`, `start.sh`.
- Push to GitHub, then **Create New Web Service** on Render and select the repo.
- Render uses: `gunicorn -k uvicorn.workers.UvicornWorker app.main:app`.
- Set env vars (Render can generate `SECRET_KEY` and you can add provider keys later).


---

## Email Invite Template (DEV)
- HTML invite email is rendered and printed in the server console with the magic link preview.

## Referral Hooks (NEW)
- Generate referral code in **Settings**; toggle “donate my discount.”
- Onboarding accepts a referral code (MVP rule: both users +10% credit).
- Credits are stored in `ReferralCredit` for future billing integration.

## Shared Thought Trails (NEW)
- Conversations and Messages are stored per workspace.
- `/api/ask` automatically adds messages to a conversation.
- UI: `/trails` to list/create; `/trails/view/{id}` to read threads.


---

## Live Sync Thought Trails + Permissions + Multi-Workspaces (NEW)
- **WebSockets** at `/ws/trails/{conversation_id}` for presence, typing, and new messages.
- **Granular roles**: owner/admin/member/viewer. Viewers are **read-only**; cannot use `/api/ask` or change settings/invites.
- **Multiple workspaces**: create and **switch** at `/workspaces`. Session tracks the active workspace.
- **Quota middleware** respects the **current workspace** selection.


---

## Phase 2 — Advanced Turbo
- **Tunable config** at `app/config/turbo_config.json` with hot-reload.
- **Advanced quality**: adds tone & formatting; normalized weighted score.
- **Learning mode**: `LearningProfile` biases provider/model selection per workspace + task.
- **Feedback API**: `POST /api/turbo/feedback` stores thumbs-up/down and adjusts bias.
- **Quick Fix API**: `POST /api/turbo/quickfix` regenerates an improved answer and appends to the trail.

### Backport to standalone idsideAITurbo
Copy these files/modules and wire routes similarly:
- `app/config/turbo_config.json`, `app/utils/turbo_config.py`, `app/utils/quality.py`
- Models: `LearningProfile`, `Feedback`
- Router: `routers/turbo.py` (or equivalent endpoints)
- Selection bias hook in your model/provider selection (if present)


---

## Phase 3 — Billing & Monetisation
- **/billing** page with plan, invoices, and top-up purchases.
- **Upgrade/Downgrade Turbo**: creates a subscription (simulated) and paid invoice; applies referral discount automatically.
- **Top-Up Packs**: buy extra request capacity; middleware **consumes top-ups before blocking** when free daily quota is reached.
- Prices & packs configurable at `app/config/billing.json`.


---

## Phase 4 — Enterprise Polish
- **Accessibility**: skip link, landmarks, ARIA labels, focus rings.
- **Loading states**: skeletons for provider status and Ask results.
- **Error boundaries**: toast messages on network/server errors.
- **Circuit breaker visibility**: `/api/status/breaker` + dashboard badges for paused providers.
- **UI tweaks**: better empty states and keyboard navigation in Thought Trails.


---

## Phase 5 — Security, Logging & QA
- **Security headers** (CSP, HSTS, X-Frame-Options, etc.) and **hardened cookies** (SameSite=Lax, HTTPS-only via `SECURE_COOKIES=true`).
- **Tight CORS**: defaults to none; set `ALLOWED_ORIGINS` when needed.
- **Structured JSON logging** and **request timing logs**.
- **Analytics events** stored in DB (`AnalyticsEvent`) with helper `utils.analytics.track`.
- **Tests**: basic smoke tests for providers and headers (`pytest`).

Run tests:
```
pytest -q
```


---

## Phase 7 — Final Enterprise Polish
- Brand-consistent theme, buttons, and panels.
- Responsive tweaks for mobile/tablet.
- Tooltips & help icons explaining key features.
- First-time user walkthrough overlay.
- Consistent form validation & submit loading states.
- Extra accessibility pass (alt text, focus, landmarks).


## SDL Complete Kit (Integrated)
This build includes the **IDECIDE SDL Complete Kit (280825)** under:
- `app/sdl_kit/`

Merged onto PyCharm_Ready_COMPLETE baseline on 2025-08-26.


## idsideAI Gold v5.3 — Features
- **Standard vs Turbo** run: `/run`
- **Decision Models** (save/reuse/export JSON/CSV/PDF): `/decision-models` and `/decision-models/view?id=...`
- **Turbo Taster** (multi-provider quick try): `/turbo-taster`
- **Dashboard** includes quick links
- **Brand polish** via `/static/css/idsideai.css`

> Note: Some legacy modules with syntax issues are archived (`*.py.disabled`) and are **not imported**.

## Quickstart (PyCharm or CLI)
```bash
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python -c "from app.utils.db import init_db; init_db()"
uvicorn app.main:app --reload
```

Updated on 2025-08-26.
