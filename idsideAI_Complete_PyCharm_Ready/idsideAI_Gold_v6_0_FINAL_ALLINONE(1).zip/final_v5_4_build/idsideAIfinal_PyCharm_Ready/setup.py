#!/usr/bin/env python3
"""
idsideAIfinal - Automated Setup Script
=====================================

This script automatically sets up the idsideAIfinal project for development.
It handles dependency installation, environment configuration, and project validation.

Usage:
    python setup.py              # Run full setup
    python setup.py --check      # Check current setup status
    python setup.py --deps-only  # Install dependencies only
"""

import sys
import os
import subprocess
import argparse
import logging
from pathlib import Path

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def run_command(command, description):
    """Run a shell command with error handling."""
    logger.info(f"{description}...")
    try:
        result = subprocess.run(
            command,
            shell=True,
            check=True,
            capture_output=True,
            text=True
        )
        logger.info(f"✅ {description} completed successfully")
        return True
    except subprocess.CalledProcessError as e:
        logger.error(f"❌ {description} failed: {e}")
        if e.stdout:
            logger.error(f"STDOUT: {e.stdout}")
        if e.stderr:
            logger.error(f"STDERR: {e.stderr}")
        return False

def check_python_version():
    """Check Python version compatibility."""
    if sys.version_info < (3, 8):
        logger.error("Python 3.8 or higher is required")
        return False
    logger.info(f"✅ Python version: {sys.version}")
    return True

def install_dependencies():
    """Install project dependencies."""
    requirements_file = Path("requirements.txt")
    if not requirements_file.exists():
        logger.error("requirements.txt not found")
        return False
    
    return run_command(
        f"{sys.executable} -m pip install -r requirements.txt",
        "Installing dependencies"
    )

def verify_installation():
    """Verify that the application can be imported."""
    try:
        from app.main import app
        logger.info("✅ Application imported successfully")
        return True
    except Exception as e:
        logger.error(f"❌ Failed to import application: {e}")
        return False

def create_env_file():
    """Create .env file if it doesn't exist."""
    env_file = Path(".env")
    env_example = Path(".env.example")
    
    if env_file.exists():
        logger.info("✅ .env file already exists")
        return True
    
    if env_example.exists():
        try:
            env_file.write_text(env_example.read_text())
            logger.info("✅ Created .env file from .env.example")
            return True
        except Exception as e:
            logger.error(f"❌ Failed to create .env file: {e}")
            return False
    else:
        # Create basic .env file
        basic_env = """# idsideAIfinal Environment Configuration
SECRET_KEY=dev-secret-change-me-in-production
SECURE_COOKIES=false
ALLOWED_ORIGINS=
DATABASE_URL=sqlite:///./idsideai.db
"""
        try:
            env_file.write_text(basic_env)
            logger.info("✅ Created basic .env file")
            return True
        except Exception as e:
            logger.error(f"❌ Failed to create .env file: {e}")
            return False

def run_setup():
    """Run the complete setup process."""
    logger.info("=== idsideAIfinal Automated Setup ===")
    
    setup_steps = [
        ("Python Version Check", check_python_version),
        ("Dependency Installation", install_dependencies),
        ("Environment File Creation", create_env_file),
        ("Installation Verification", verify_installation)
    ]
    
    all_passed = True
    for name, step_func in setup_steps:
        logger.info(f"Running: {name}")
        if not step_func():
            all_passed = False
            logger.error(f"Setup step failed: {name}")
            break
    
    if all_passed:
        logger.info("🎉 Setup completed successfully!")
        logger.info("You can now run the application with: python run.py")
        logger.info("Or open the project in PyCharm and click 'Run idsideAIfinal'")
        return True
    else:
        logger.error("❌ Setup failed. Please check the errors above.")
        return False

def check_setup():
    """Check the current setup status."""
    logger.info("=== idsideAIfinal Setup Status Check ===")
    
    checks = [
        ("Python Version", check_python_version),
        ("Application Import", verify_installation)
    ]
    
    all_passed = True
    for name, check_func in checks:
        logger.info(f"Checking: {name}")
        if check_func():
            logger.info(f"✅ {name}: OK")
        else:
            logger.error(f"❌ {name}: FAILED")
            all_passed = False
    
    if all_passed:
        logger.info("🎉 All checks passed! Project is ready to use.")
        return True
    else:
        logger.error("❌ Some checks failed. Run 'python setup.py' to fix issues.")
        return False

def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description="idsideAIfinal Automated Setup Script",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
    python setup.py              # Run complete setup
    python setup.py --check      # Check setup status
    python setup.py --deps-only  # Install dependencies only

This script will:
1. Check Python version compatibility
2. Install required dependencies
3. Create environment configuration
4. Verify the installation
        """
    )
    
    parser.add_argument(
        "--check",
        action="store_true",
        help="Check setup status without making changes"
    )
    
    parser.add_argument(
        "--deps-only",
        action="store_true",
        help="Install dependencies only"
    )
    
    args = parser.parse_args()
    
    try:
        if args.check:
            success = check_setup()
        elif args.deps_only:
            success = check_python_version() and install_dependencies()
        else:
            success = run_setup()
        
        sys.exit(0 if success else 1)
        
    except KeyboardInterrupt:
        logger.info("Setup interrupted by user")
        sys.exit(1)
    except Exception as e:
        logger.error(f"Unexpected error during setup: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()

