
from datetime import date
from app.utils.db import get_session
from app.models.quota import RequestQuota

def get_or_create_quota(user_id: int) -> RequestQuota:
    today = date.today()
    with get_session() as session:
        q = session.exec(RequestQuota.select().where(RequestQuota.user_id==user_id, RequestQuota.day==today)).first()  # type: ignore
        if not q:
            q = RequestQuota(user_id=user_id, day=today, used=0, limit=20)
            session.add(q)
            session.commit()
            session.refresh(q)
        return q
