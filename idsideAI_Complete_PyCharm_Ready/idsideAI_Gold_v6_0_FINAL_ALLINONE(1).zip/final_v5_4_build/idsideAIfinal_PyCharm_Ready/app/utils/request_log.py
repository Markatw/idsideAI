
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
import time, logging

log = logging.getLogger("request")

class RequestLogMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        t0 = time.time()
        path = request.url.path
        method = request.method
        uid = request.session.get("user_id")
        try:
            resp = await call_next(request)
            status = resp.status_code
        except Exception as e:
            status = 500
            raise
        finally:
            ms = int((time.time()-t0)*1000)
            log.info("http", extra={"args": {"path": path, "method": method, "status": status, "ms": ms, "uid": uid}})
        return resp
