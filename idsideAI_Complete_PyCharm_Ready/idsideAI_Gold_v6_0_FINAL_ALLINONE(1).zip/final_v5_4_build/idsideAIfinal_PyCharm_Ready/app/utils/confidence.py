
from typing import Optional
from app.utils.db import get_session
from app.models.provider_telemetry import ProviderTelemetry

def compute_confidence(workspace_id: Optional[int], provider: str, model: str, base_quality: float) -> float:
    # Use last ~200 rows to compute ok rate and avg latency
    if not workspace_id:
        return round(max(0.0, min(1.0, base_quality)), 4)
    with get_session() as session:
        rows = session.exec(ProviderTelemetry.select().where(ProviderTelemetry.workspace_id==workspace_id, ProviderTelemetry.provider==provider, ProviderTelemetry.model==model).order_by(ProviderTelemetry.id.desc())).all()  # type: ignore
        rows = rows[:200]
        if not rows:
            return round(max(0.0, min(1.0, base_quality)), 4)
        ok_rate = sum(int(r.success) for r in rows) / max(1, len(rows))
        avg_ms = sum(r.latency_ms for r in rows) / max(1, len(rows))
        # weight base quality (60%), ok_rate (30%), latency (10% inverted)
        lat_factor = 1.0 - min(avg_ms/6000.0, 1.0)
        conf = base_quality*0.6 + ok_rate*0.3 + lat_factor*0.1
        return round(max(0.0, min(1.0, conf)), 4)
