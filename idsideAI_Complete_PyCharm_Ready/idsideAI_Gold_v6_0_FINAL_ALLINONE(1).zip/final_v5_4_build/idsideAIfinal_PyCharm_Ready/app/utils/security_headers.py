
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response
import os

# Basic security headers. In production behind HTTPS, set SECURE_COOKIES=true
CSP = "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'"
HSTS = "max-age=31536000; includeSubDomains"
REFERRER = "no-referrer"

class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        resp: Response = await call_next(request)
        resp.headers.setdefault("Content-Security-Policy", CSP)
        resp.headers.setdefault("X-Content-Type-Options", "nosniff")
        resp.headers.setdefault("X-Frame-Options", "DENY")
        resp.headers.setdefault("Referrer-Policy", REFERRER)
        if os.getenv("SECURE_COOKIES", "false").lower() in ("1","true","yes"):
            resp.headers.setdefault("Strict-Transport-Security", HSTS)
        return resp
