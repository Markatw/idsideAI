
from typing import Optional
from app.utils.db import get_session
from app.models.membership import Membership

def current_role(user_id: int, workspace_id: Optional[int]) -> str:
    if not workspace_id:
        return "member"
    with get_session() as session:
        mem = session.exec(Membership.select().where(Membership.user_id==user_id, Membership.workspace_id==workspace_id)).first()  # type: ignore
        return mem.role if mem else "member"

def can_invite(role: str) -> bool:
    return role in ("owner","admin")

def can_ask(role: str) -> bool:
    return role in ("owner","admin","member")  # viewer cannot

def can_manage_settings(role: str) -> bool:
    return role in ("owner","admin")
