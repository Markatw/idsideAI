
from __future__ import annotations
from typing import Dict
import math
from .turbo_config import get_turbo_config

def clamp(x: float, lo: float=0.0, hi: float=1.0) -> float:
    return max(lo, min(hi, x))

def derive_factors(prompt: str, text: str, latency_ms: float) -> Dict[str, float]:
    # Token heuristics
    p_tokens = set(t.lower() for t in prompt.split() if len(t) > 3)
    t_tokens = set(t.lower() for t in text.split() if len(t) > 3)
    overlap = len(p_tokens & t_tokens)
    acc = clamp(overlap / (len(p_tokens) + 1e-6))

    # Completeness: bell around 250 words
    out_words = len(text.split())
    comp = clamp(math.exp(-((out_words-250)/300)**2))

    # Adherence: penalize novelty vs prompt
    extra = len(t_tokens - p_tokens)
    adh = clamp(1.0 - (extra / (len(t_tokens)+1e-6)) * 0.5)

    # Speed
    if latency_ms <= 500: spd = 1.0
    elif latency_ms >= 8000: spd = 0.2
    else: spd = clamp(1.0 - (latency_ms-500)/7500)

    # Tone: crude proxy—avoid all caps, exclamation spam; use 1 if calm.
    excls = text.count("!")
    caps_ratio = sum(1 for c in text if c.isupper()) / (len(text)+1e-6)
    tone = clamp(1.0 - 0.6*min(excls/10.0, 1.0) - 0.4*min(caps_ratio/0.2, 1.0))

    # Formatting: presence of paragraphs, bullets, headings
    has_para = "\n\n" in text
    bullets = text.count("- ") + text.count("* ")
    headings = text.count("\n#")
    fmt = clamp(0.4*int(has_para) + 0.4*min(bullets/3.0,1.0) + 0.2*min(headings/2.0,1.0))

    return {"accuracy": acc, "completeness": comp, "adherence": adh, "speed": spd, "tone": tone, "formatting": fmt}

def score_quality(prompt: str, text: str, latency_ms: float) -> Dict[str, float]:
    cfg = get_turbo_config()
    w = cfg.get("_weights_norm", {})
    f = derive_factors(prompt, text, latency_ms)
    overall = sum(f.get(k,0.0)*w.get(k,0.0) for k in set(f)|set(w))
    f["overall"] = clamp(overall)
    return f
