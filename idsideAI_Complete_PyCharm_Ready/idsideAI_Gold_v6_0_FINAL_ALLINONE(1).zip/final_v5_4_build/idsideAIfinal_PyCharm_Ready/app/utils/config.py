
import os

def env(name: str, default: str = "") -> str:
    return os.getenv(name, default)

def env_float(name: str, default: float) -> float:
    try:
        return float(os.getenv(name, str(default)))
    except ValueError:
        return default

def provider_default_model(name: str) -> str:
    # e.g., PROVIDER_DEFAULT_MODEL_OPENAI=gpt-4o-mini
    return os.getenv(f"PROVIDER_DEFAULT_MODEL_{name.upper()}", "auto")

REQUEST_TIMEOUT_S = env_float("PROVIDER_TIMEOUT_S", 18.0)
MODEL_CACHE_TTL_S = env_float("MODEL_CACHE_TTL_S", 3600.0)  # 1 hour


CB_FAIL_THRESHOLD = int(os.getenv("CB_FAIL_THRESHOLD", "3"))
CB_COOLDOWN_SECONDS = env_float("CB_COOLDOWN_SECONDS", 30.0)
