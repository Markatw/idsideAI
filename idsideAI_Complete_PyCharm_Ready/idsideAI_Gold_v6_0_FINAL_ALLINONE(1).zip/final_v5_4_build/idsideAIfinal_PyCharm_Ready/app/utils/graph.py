from typing import Dict, List, Any, Tuple
import json

def normalise_graph(graph: Dict[str, Any]) -> Dict[str, Any]:
    nodes = graph.get("nodes", [])
    edges = graph.get("edges", [])
    return {"nodes": nodes, "edges": edges, "meta": graph.get("meta", {})}

def graph_to_csv_rows(graph: Dict[str, Any]) -> Tuple[List[List[str]], List[List[str]]]:
    g = normalise_graph(graph)
    node_rows = [["node_id","label","type","evidence","risk","outcome"]]
    for n in g["nodes"]:
        node_rows.append([
            str(n.get("id","")),
            str(n.get("label","")),
            str(n.get("type","")),
            json.dumps(n.get("evidence",[])),
            json.dumps(n.get("risk",[])),
            json.dumps(n.get("outcome",{})),
        ])
    edge_rows = [["src","dst","label","weight"]]
    for e in g["edges"]:
        edge_rows.append([
            str(e.get("source","")),
            str(e.get("target","")),
            str(e.get("label","")),
            str(e.get("weight",""))
        ])
    return node_rows, edge_rows