
import time
from typing import Dict

class CircuitBreaker:
    def __init__(self, fail_threshold: int = 3, cooldown_seconds: float = 30.0):
        self.fail_threshold = fail_threshold
        self.cooldown_seconds = cooldown_seconds
        self.fail_counts: Dict[str, int] = {}
        self.open_until: Dict[str, float] = {}

    def record_success(self, name: str):
        self.fail_counts[name] = 0
        self.open_until.pop(name, None)

    def record_failure(self, name: str):
        c = self.fail_counts.get(name, 0) + 1
        self.fail_counts[name] = c
        if c >= self.fail_threshold:
            self.open_until[name] = time.time() + self.cooldown_seconds

    def is_open(self, name: str) -> bool:
        until = self.open_until.get(name, 0)
        if until and time.time() < until:
            return True
        if until and time.time() >= until:
            # cooldown expired
            self.open_until.pop(name, None)
            self.fail_counts[name] = 0
        return False

# Global singleton for app instance (simple process-local)
breaker = CircuitBreaker()


def state():
    # Expose a safe snapshot: fail counts and open-until timestamps
    return {"fail_counts": dict(breaker.fail_counts), "open_until": dict(breaker.open_until)}
