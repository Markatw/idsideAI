
import os, sys
from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired

SECRET = os.getenv("SECRET_KEY", "dev-secret-change-me")
SIGN_SALT = "idsideai-auth"
TOKEN_TTL = int(os.getenv("MAGICLINK_TTL_SECONDS", "900"))  # 15 min default

def get_signer():
    return URLSafeTimedSerializer(SECRET, salt=SIGN_SALT)

def sign_email(email: str) -> str:
    s = get_signer()
    return s.dumps({"email": email})

def verify_token(token: str):
    s = get_signer()
    try:
        data = s.loads(token, max_age=TOKEN_TTL)
        return data.get("email")
    except SignatureExpired:
        return None
    except BadSignature:
        return None

def dev_send_email(to_email: str, link: str):
    # Dev-only: print to console so you can click
    print(f"""\n=== MAGIC LINK (DEV) ===\nTo: {to_email}\n{link}\n========================\n""", file=sys.stderr)
