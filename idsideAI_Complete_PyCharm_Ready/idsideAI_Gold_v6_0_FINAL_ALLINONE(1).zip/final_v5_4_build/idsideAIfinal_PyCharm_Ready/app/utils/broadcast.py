
from app.utils.realtime import manager
async def broadcast_assistant(conversation_id: int, provider: str, model: str, text: str, latency_ms: float):
    await manager.broadcast(conversation_id, {
        "type":"message",
        "role":"assistant",
        "provider": provider,
        "model": model,
        "text": text,
        "latency_ms": latency_ms
    })
