
from typing import Tuple
def optimize_prompt(task: str, provider: str | None, prompt: str) -> Tuple[str, str]:
    # simple rules; could expand per provider
    rules = []
    if task == "code":
        rules.append("Specify language and desired style (idiomatic/concise).")
    if task == "long_form":
        rules.append("Ask for structured sections and concise paragraphs.")
    if task == "search_qa":
        rules.append("Ask for brief, cited answers where possible.")
    if provider and provider.lower().startswith("groq"):
        rules.append("Prefer concise outputs due to speed focus.")
    instruction = " ".join(rules)
    if not instruction:
        return prompt, ""
    new = f"""Improve this prompt following: {instruction}
---
{prompt}
---
Return only the rewritten prompt."""
    return new, instruction
