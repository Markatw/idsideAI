
from typing import Dict, Set, Any
from fastapi import WebSocket
from asyncio import Lock

class RealtimeManager:
    def __init__(self):
        self.rooms: Dict[int, Set[WebSocket]] = {}
        self.lock = Lock()

    async def connect(self, room_id: int, ws: WebSocket):
        await ws.accept()
        async with self.lock:
            if room_id not in self.rooms:
                self.rooms[room_id] = set()
            self.rooms[room_id].add(ws)

    async def disconnect(self, room_id: int, ws: WebSocket):
        async with self.lock:
            room = self.rooms.get(room_id, set())
            if ws in room:
                room.remove(ws)
            if not room and room_id in self.rooms:
                self.rooms.pop(room_id, None)

    async def broadcast(self, room_id: int, message: Any):
        room = self.rooms.get(room_id, set())
        dead = []
        for ws in list(room):
            try:
                await ws.send_json(message)
            except Exception:
                dead.append(ws)
        for ws in dead:
            await self.disconnect(room_id, ws)

manager = RealtimeManager()
