
import logging, json, time, os
from typing import Any, Dict

class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        base = {
            "level": record.levelname,
            "time": int(time.time() * 1000),
            "message": record.getMessage(),
            "logger": record.name,
        }
        if record.args and isinstance(record.args, dict):
            base.update(record.args)
        return json.dumps(base, ensure_ascii=False)

def configure_logging():
    logger = logging.getLogger()
    if logger.handlers:
        return
    h = logging.StreamHandler()
    h.setFormatter(JsonFormatter())
    logger.addHandler(h)
    logger.setLevel(logging.INFO)
    # reduce noisy loggers
    logging.getLogger("uvicorn.access").setLevel(logging.WARNING)
    logging.getLogger("httpx").setLevel(logging.WARNING)

configure_logging()
