
import json
from typing import Optional, Dict, Any
from app.utils.db import get_session
from app.models.analytics_event import AnalyticsEvent

def track(event: str, user_id: Optional[int], workspace_id: Optional[int], meta: Dict[str, Any] | None = None):
    with get_session() as session:
        a = AnalyticsEvent(user_id=user_id, workspace_id=workspace_id, event=event, meta=json.dumps(meta or {}))
        session.add(a); session.commit()
