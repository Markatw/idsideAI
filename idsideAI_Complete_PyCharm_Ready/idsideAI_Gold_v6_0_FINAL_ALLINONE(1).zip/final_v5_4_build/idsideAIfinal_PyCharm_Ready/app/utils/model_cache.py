
import time
from typing import Dict, List, Tuple

class ModelCache:
    def __init__(self, ttl_seconds: float = 3600.0):
        self.ttl = ttl_seconds
        self._cache: Dict[str, Tuple[float, List[str]]] = {}

    def get(self, provider: str):
        now = time.time()
        entry = self._cache.get(provider)
        if not entry:
            return None
        ts, models = entry
        if now - ts > self.ttl:
            return None
        return models

    def set(self, provider: str, models: List[str]):
        self._cache[provider] = (time.time(), models)
