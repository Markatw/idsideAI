
import os, sys
from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired

SECRET = os.getenv("SECRET_KEY", "dev-secret-change-me")
INVITE_SALT = "idsideai-invite"
INVITE_TTL = int(os.getenv("INVITE_TTL_SECONDS", "604800"))  # 7 days

def get_invite_signer():
    return URLSafeTimedSerializer(SECRET, salt=INVITE_SALT)

def make_invite_token(email: str, workspace_id: int, role: str) -> str:
    s = get_invite_signer()
    return s.dumps({"email": email, "workspace_id": workspace_id, "role": role})

def verify_invite_token(token: str):
    s = get_invite_signer()
    try:
        data = s.loads(token, max_age=INVITE_TTL)
        return data  # dict with email, workspace_id, role
    except (BadSignature, SignatureExpired):
        return None

def dev_send_invite(email: str, link: str):
    html = render_email_invite(link)
    print(f"""\n=== WORKSPACE INVITE (DEV) ===\nTo: {email}\nLink: {link}\n--- HTML PREVIEW ---\n{html}\n--------------------\n""", file=sys.stderr)


def render_email_invite(link: str) -> str:
    # Minimal inline template rendering (no Jinja in utils); we just inject link.
    html = """
<!DOCTYPE html>
<html>
  <body style=\"font-family:Arial,Helvetica,sans-serif; background:#f6f8fb; padding:20px\">
    <table width=\"100%%\" cellpadding=\"0\" cellspacing=\"0\" style=\"max-width:560px; margin:auto; background:#ffffff; border-radius:12px; overflow:hidden; border:1px solid #e6ecf5\">
      <tr>
        <td style=\"background:linear-gradient(90deg,#0b61d6,#1f8bff); color:white; padding:16px 20px; font-weight:700\">idsideAI — Workspace Invite</td>
      </tr>
      <tr>
        <td style=\"padding:20px\">
          <p>Hi,</p>
          <p>You’ve been invited to join a workspace on <strong>idsideAI</strong>.</p>
          <p><a href=\"{{ link }}\" style=\"background:#0b61d6; color:#fff; padding:10px 14px; border-radius:10px; text-decoration:none; font-weight:700\">Accept invite</a></p>
          <p>If the button doesn’t work, paste this link in your browser:</p>
          <code style=\"display:block; padding:10px; background:#f1f5ff; border-radius:8px; word-break:break-all\">{{ link }}</code>
          <p style=\"color:#6b7280; font-size:12px\">This link expires in 7 days.</p>
        </td>
      </tr>
    </table>
  </body>
</html>
"""
    return html.replace("{ link }", link)
