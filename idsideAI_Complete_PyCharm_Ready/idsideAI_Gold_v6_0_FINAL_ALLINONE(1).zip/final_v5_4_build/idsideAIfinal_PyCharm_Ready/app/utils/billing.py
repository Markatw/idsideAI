
import json, os
from typing import Dict, Any
from app.utils.db import get_session
from app.models.referral_credit import ReferralCredit

CFG_PATH = os.path.join(os.path.dirname(__file__), "..", "config", "billing.json")

def load_billing() -> Dict[str, Any]:
    with open(CFG_PATH, "r", encoding="utf-8") as f:
        return json.load(f)

def price_with_referral(user_id: int, base_price: float) -> float:
    with get_session() as session:
        credit = session.exec(ReferralCredit.select().where(ReferralCredit.user_id==user_id)).first()  # type: ignore
        percent = credit.percent if credit else 0
    return round(base_price * (1.0 - (percent/100.0)), 2)
