
import json, os, time
from typing import Any, Dict

_CFG_PATH = os.path.join(os.path.dirname(__file__), "..", "config", "turbo_config.json")
_cache: Dict[str, Any] = {}
_mtime = 0.0

def get_turbo_config() -> Dict[str, Any]:
    global _cache, _mtime
    try:
        st = os.stat(_CFG_PATH)
        if st.st_mtime != _mtime or not _cache:
            with open(_CFG_PATH, "r", encoding="utf-8") as f:
                data = json.load(f)
            # basic validation
            qw = data.get("quality_weights", {})
            if not isinstance(qw, dict) or not qw:
                raise ValueError("quality_weights invalid")
            # normalise weights
            total = sum(float(v) for v in qw.values() if isinstance(v, (int,float)))
            if total <= 0: total = 1.0
            data["_weights_norm"] = {k: float(v)/total for k,v in qw.items() if isinstance(v,(int,float))}
            _cache = data
            _mtime = st.st_mtime
    except Exception:
        # fallback defaults
        _cache = {"_weights_norm":{"accuracy":0.5,"completeness":0.2,"adherence":0.2,"speed":0.1}}
    return _cache
