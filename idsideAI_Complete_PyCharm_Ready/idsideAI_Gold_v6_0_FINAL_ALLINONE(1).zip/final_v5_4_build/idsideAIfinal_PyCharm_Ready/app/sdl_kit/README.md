# IDECIDE — Ultimate SDL Complete Kit

This bundle combines:
1) **Ultimate SDL Package** (spec, hi‑fi mockups, storyboard, motion blueprint, Figma tokens)
2) **React SDL Scaffold** (Vite + TS) wired to a **Dummy Graph API**

## Quick Start
### 1) API
```bash
cd api
python -m venv .venv && source .venv/bin/activate   # .venv\Scripts\activate on Windows
pip install -r requirements.txt
uvicorn app:app --reload --port 8000
```

### 2) Frontend
```bash
cd frontend
cp .env.example .env    # optional; defaults to http://localhost:8000
npm install
npm run dev
```
Open http://localhost:5173 — you’ll see the SDL canvas rendering data from the API.
Click nodes to populate the Inspector. Evidence shows a confidence ring pulse.

## Figma
- Import `figma_tokens.json` using Tokens Studio.
- Use the **Figma Handoff Checklist.pdf** (inside the scaffold) to build the interactive prototype.

## Contents
- `/api` — Dummy Graph API (FastAPI)
- `/frontend` — React SDL scaffold
- `/Ultimate_SDL` — Spec, hi‑fi mockups, storyboard, tokens, motion blueprint


## New in this build
- Tenant middleware with X-Tenant/X-Workspace enforcement.
- Snapshots persisted in Neo4j (Snapshot nodes linked to Graph).
- Audit export ZIP endpoint + Why PDF export.
- Toolbar Snapshot/Compare/Export wired; density & renderer toggles.
- Docker Compose for full stack; CI workflow stub.


## New in this build
- Evidence metadata (url/source/date/author) + hover previews
- Minimap overlay, Undo/Redo, Download Queue
- Why Export includes citations with live URLs (dummy + Neo4j)
- WebGL clustering with semantic labels stub
- CI workflow stub
