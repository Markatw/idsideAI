# Accessibility Report (Initial)

- Added semantic roles and `aria-label` for graph canvas.
- Keyboard focus rings enabled globally.
- Next: full keyboard navigation for node traversal, inspector tabs, and toolbar actions.
