
from fastapi import APIRouter, Request, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from app.utils.db import get_session
from app.models.membership import Membership
from app.models.conversation import Conversation
from app.models.message import Message

router = APIRouter(prefix="/trails", tags=["trails"])
templates = Jinja2Templates(directory="app/templates")

def current_workspace_id(session, user_id: int):
    mem = session.exec(Membership.select().where(Membership.user_id==user_id)).first()  # type: ignore
    return mem.workspace_id if mem else None

@router.get("", response_class=HTMLResponse)
async def list_trails(request: Request):
    if not request.session.get('user_id'):
        return RedirectResponse(url='/auth/signin', status_code=303)
    uid = request.session['user_id']
    with get_session() as session:
        ws_id = current_workspace_id(session, uid)
        convs = session.exec(Conversation.select().where(Conversation.workspace_id==ws_id).order_by(Conversation.id.desc())).all()  # type: ignore
    return templates.TemplateResponse("trails.html", {"request": request, "conversations": convs})

@router.post("/new")
async def new_trail(request: Request, title: str = Form("Untitled")):
    if not request.session.get('user_id'):
        return RedirectResponse(url='/auth/signin', status_code=303)
    uid = request.session['user_id']
    with get_session() as session:
        ws_id = current_workspace_id(session, uid)
        c = Conversation(workspace_id=ws_id, title=title or "Untitled", created_by=uid)
        session.add(c); session.commit(); session.refresh(c)
    return RedirectResponse(url=f"/trails/view/{c.id}", status_code=303)

@router.get("/view/{cid}", response_class=HTMLResponse)
async def view_trail(request: Request, cid: int):
    if not request.session.get('user_id'):
        return RedirectResponse(url='/auth/signin', status_code=303)
    with get_session() as session:
        conv = session.get(Conversation, cid)
        msgs = session.exec(Message.select().where(Message.conversation_id==cid).order_by(Message.id.asc())).all()  # type: ignore
    return templates.TemplateResponse("trail_view.html", {"request": request, "conv": conv, "messages": msgs})
