
from fastapi import APIRouter, Request, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from app.models.onboarding import OnboardingInput
from app.services.turbo import TurboSummary
from app.services.model_router import ModelRouter
from app.utils.db import get_session
from app.models.user import User
from app.models.workspace import Workspace
from app.models.membership import Membership
from app.models.onboarding_selection import OnboardingSelection
from app.models.invite import Invite
from app.utils.invite import make_invite_token, dev_send_invite
from urllib.parse import urlencode

templates = Jinja2Templates(directory="app/templates")
router = APIRouter(tags=["onboarding"])

def _noop():
    return None
    # Placeholder: until auth, store an email in session or default
    email = "demo@idside.ai"
    user = session.exec(User.select().where(User.email == email)).first()  # type: ignore
    if not user:
        user = User(email=email)
        session.add(user)
        session.commit()
        session.refresh(user)
    return user

@router.get("/onboarding", response_class=HTMLResponse)
async def get_onboarding(request: Request):
    if not request.session.get('user_id'):
        return RedirectResponse(url='/auth/signin', status_code=303)
    turbo_summary = TurboSummary().summary()
    return templates.TemplateResponse("onboarding.html", {"request": request, "turbo": turbo_summary})

@router.post("/onboarding", response_class=HTMLResponse)
async def post_onboarding(
    request: Request,
    plan: str = Form(...),
    workspace: str = Form(...),
    collaborators: str = Form(""),
    turbo_opt_in: str = Form("no"),
    ref_code: str = Form("")
):
    if not request.session.get('user_id'):
        return RedirectResponse(url='/auth/signin', status_code=303)
    data = OnboardingInput(
        plan=plan,
        workspace=workspace,
        collaborators=[c.strip() for c in collaborators.split(",") if c.strip()],
        turbo_opt_in=(turbo_opt_in == "yes")
    )
    # Persist
    with get_session() as session:
        user = _noop(session)
        ws = Workspace(kind=data.workspace, name=f"{data.workspace.title()} Workspace")
        session.add(ws)
        session.commit()
        session.refresh(ws)

        member = Membership(user_id=user.id, workspace_id=ws.id, role="owner")
        session.add(member)

        ob = OnboardingSelection(user_id=user.id, plan=data.plan, turbo_opt_in=data.turbo_opt_in)
        session.add(ob)
        session.commit()

        # auto-send invites
        base = str(request.base_url).rstrip("/")
        for email in data.collaborators:
            tok = make_invite_token(email=email, workspace_id=ws.id, role="member")
            inv = Invite(workspace_id=ws.id, email=email, role="member", token=tok, status="pending")
            session.add(inv); session.commit()
            link = f"{base}/collab/accept?{urlencode({'token': tok})}"
            dev_send_invite(email, link)
        
    # Referral processing (MVP: +10% both sides)
    rc = (ref_code or '').strip()
    if rc:
        from app.models.referral_link import ReferralLink
        from app.models.referral_redemption import ReferralRedemption
        from app.models.referral_credit import ReferralCredit
        link = session.exec(ReferralLink.select().where(ReferralLink.code==rc)).first()  # type: ignore
        if link and link.owner_user_id != user.id:
            red = ReferralRedemption(code=rc, referred_user_id=user.id)
            session.add(red)
            # credit owner
            own = session.exec(ReferralCredit.select().where(ReferralCredit.user_id==link.owner_user_id)).first()  # type: ignore
            if not own:
                from app.models.referral_credit import ReferralCredit as RC
                own = RC(user_id=link.owner_user_id, percent=0)
            own.percent = min(100, own.percent + 10)
            session.add(own)
            # credit referred
            ref = session.exec(ReferralCredit.select().where(ReferralCredit.user_id==user.id)).first()  # type: ignore
            if not ref:
                from app.models.referral_credit import ReferralCredit as RC
                ref = RC(user_id=user.id, percent=0)
            ref.percent = min(100, ref.percent + 10)
            session.add(ref)
            session.commit()
    _ = ModelRouter().route_intent("Welcome message")
    return RedirectResponse(url="/dashboard", status_code=303)
