
from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from app.utils.db import get_session
from app.models.metric import Metric

templates = Jinja2Templates(directory="app/templates")
router = APIRouter(tags=["dashboard"])

@router.get("/dashboard", response_class=HTMLResponse)
async def dashboard(request: Request):
    if not request.session.get('user_id'):
        return RedirectResponse(url='/auth/signin', status_code=303)
    # Compute user averages over the last 20 metrics
    metrics = {"accuracy": 0.0, "completeness": 0.0, "adherence": 0.0, "speed": 0.0}
    uid = request.session.get('user_id')
    if uid:
        with get_session() as session:
            rows = session.exec(Metric.select().where(Metric.user_id==uid).order_by(Metric.id.desc())).all()  # type: ignore
            rows = rows[:20]
            if rows:
                n = len(rows)
                metrics = {
                    "accuracy": sum(r.accuracy for r in rows)/n,
                    "completeness": sum(r.completeness for r in rows)/n,
                    "adherence": sum(r.adherence for r in rows)/n,
                    "speed": sum(r.speed for r in rows)/n,
                }
    # pull plan/quota
    user_id = request.session.get('user_id')
    plan_name, turbo = 'free', False
    remaining, limit = None, None
    if user_id:
        with get_session() as session:
            ob = session.exec(OnboardingSelection.select().where(OnboardingSelection.user_id==user_id)).first()  # type: ignore
            if ob:
                plan_name = ob.plan
                turbo = bool(ob.turbo_opt_in)
            from datetime import date
            q = session.exec(RequestQuota.select().where(RequestQuota.user_id==user_id, RequestQuota.day==date.today())).first()  # type: ignore
            if q:
                limit = q.limit
                remaining = max(q.limit - q.used, 0)
    last = request.session.get('last_selection', {"provider": None, "model": None})
    ctx = {"request": request, "metrics": metrics, "plan": plan_name, "turbo": turbo, "quota_remaining": remaining, "quota_limit": limit, "last": last, "member_count": (len(session.exec(Membership.select().where(Membership.workspace_id==ws.id)).all()) if (uid and (ws:=session.exec(Membership.select().where(Membership.user_id==uid)).first())) else None), "telemetry": session.exec(ProviderTelemetry.select().order_by(ProviderTelemetry.id.desc())).all(), "learnlog": session.exec(LearningLog.select().order_by(LearningLog.id.desc())).all()}
    return templates.TemplateResponse("dashboard.html", ctx)
