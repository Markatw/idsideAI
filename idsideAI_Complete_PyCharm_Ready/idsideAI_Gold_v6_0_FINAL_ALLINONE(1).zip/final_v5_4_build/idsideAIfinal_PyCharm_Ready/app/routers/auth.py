
from fastapi import APIRouter, Request, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, EmailStr, ValidationError
from urllib.parse import urlencode
from app.utils.db import get_session
from app.models.user import User
from app.utils.auth import sign_email, verify_token, dev_send_email

templates = Jinja2Templates(directory="app/templates")
router = APIRouter(prefix="/auth", tags=["auth"])

@router.get("/signin", response_class=HTMLResponse)
async def signin_form(request: Request):
    return templates.TemplateResponse("signin.html", {"request": request, "sent": False})

@router.post("/signin", response_class=HTMLResponse)
async def signin_submit(request: Request, email: str = Form(...)):
    try:
        _ = EmailStr(email)  # validate
    except ValidationError:
        return templates.TemplateResponse("signin.html", {"request": request, "sent": False, "error": "Invalid email."})
    token = sign_email(email)
    # Build link
    base_url = str(request.base_url).rstrip("/")
    link = f"{base_url}/auth/verify?{urlencode({'token': token})}"
    dev_send_email(email, link)
    return templates.TemplateResponse("signin.html", {"request": request, "sent": True, "email": email})

@router.get("/verify")
async def verify(request: Request, token: str):
    email = verify_token(token)
    if not email:
        return templates.TemplateResponse("signin.html", {"request": request, "sent": False, "error": "Invalid or expired link. Try again."})
    # Create or fetch user
    with get_session() as session:
        user = session.exec(User.select().where(User.email==email)).first()  # type: ignore
        if not user:
            user = User(email=email)
            session.add(user)
            session.commit()
            session.refresh(user)
        request.session["user_id"] = user.id
        request.session["email"] = user.email
    return RedirectResponse(url="/onboarding", status_code=303)

@router.get("/signout")
async def signout(request: Request):
    request.session.clear()
    return RedirectResponse(url="/", status_code=303)
