from fastapi import APIRouter, HTTPException, Request, Response, Query
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
import io, csv, json
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from app.services.decision_model_service import (
    create_decision_model, list_decision_models, get_decision_model, update_decision_model
)
from app.utils.graph import normalise_graph, graph_to_csv_rows

router = APIRouter(prefix="/decision-models", tags=["decision-models"])

class DecisionModelIn(BaseModel):
    name: str = "Untitled Decision Model"
    description: str = ""
    tags: List[str] = []
    graph: Dict[str, Any] = {}
    turbo_used: bool = False

@router.get("")
async def list_models(request: Request, q: Optional[str]=Query(None), tag: Optional[str]=Query(None)):
    uid = request.session.get("user_id") if hasattr(request, "session") else None
    models = list_decision_models(uid)
    out = []
    for m in models:
        tags = []
        try:
            tags = json.loads(m.tags or "[]")
        except Exception:
            pass
        if q and q.lower() not in (m.name.lower() + " " + (m.description or "").lower()):
            continue
        if tag and tag.lower() not in [str(t).lower() for t in tags]:
            continue
        out.append({"id": m.id, "name": m.name, "description": m.description, "tags": tags, "version": m.version, "turbo_used": m.turbo_used})
    return out

@router.post("")
async def create_model(request: Request, body: DecisionModelIn):
    uid = request.session.get("user_id") if hasattr(request, "session") else None
    dm = create_decision_model(body.name, body.description, body.tags, body.graph, body.turbo_used, uid)
    return {"id": dm.id, "name": dm.name, "description": dm.description, "tags": body.tags, "version": dm.version, "turbo_used": dm.turbo_used}

@router.get("/{dm_id}")
async def get_model(dm_id: int, request: Request):
    uid = request.session.get("user_id") if hasattr(request, "session") else None
    dm = get_decision_model(dm_id, uid)
    if not dm:
        raise HTTPException(404, "Decision Model not found")
    tags = []
    try:
        tags = json.loads(dm.tags or "[]")
    except Exception:
        pass
    return {"id": dm.id, "name": dm.name, "description": dm.description, "tags": tags, "version": dm.version, "turbo_used": dm.turbo_used, "graph": json.loads(dm.graph_json or "{}")}

@router.post("/{dm_id}")
async def update_model(dm_id: int, body: dict, request: Request):
    uid = request.session.get("user_id") if hasattr(request, "session") else None
    dm = update_decision_model(dm_id, body, uid)
    if not dm:
        raise HTTPException(404, "Decision Model not found")
    return {"ok": True}

@router.get("/{dm_id}/export")
async def export_model(request: Request, dm_id: int, fmt: str = "json"):
    uid = request.session.get("user_id") if hasattr(request, "session") else None
    dm = get_decision_model(dm_id, uid)
    if not dm:
        raise HTTPException(404, "Decision Model not found")
    graph = normalise_graph(json.loads(dm.graph_json or "{}"))

    if fmt == "json":
        return graph

    if fmt == "csv":
        node_rows, edge_rows = graph_to_csv_rows(graph)
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(["# Decision Model:", dm.name])
        w.writerow([]); w.writerow(["# Nodes"]); w.writerows(node_rows)
        w.writerow([]); w.writerow(["# Edges"]); w.writerows(edge_rows)
        return Response(content=buf.getvalue(), media_type="text/csv", headers={"Content-Disposition": f"attachment; filename=decision_model_{dm_id}.csv"})

    if fmt == "pdf":
        buf = io.BytesIO()
        doc = SimpleDocTemplate(buf, pagesize=A4)
        styles = getSampleStyleSheet()
        story = []
        story.append(Paragraph(f"Decision Model: {dm.name}", styles['Title']))
        story.append(Paragraph(dm.description or "", styles['BodyText'])); story.append(Spacer(1,12))
        node_rows, edge_rows = graph_to_csv_rows(graph)
        story.append(Paragraph("Nodes", styles['Heading2'])); story.append(Table(node_rows))
        story.append(Spacer(1,12))
        story.append(Paragraph("Edges", styles['Heading2'])); story.append(Table(edge_rows))
        doc.build(story)
        pdf = buf.getvalue()
        return Response(content=pdf, media_type="application/pdf", headers={"Content-Disposition": f"attachment; filename=decision_model_{dm_id}.pdf"})

    raise HTTPException(400, "Unsupported format")