
from fastapi import APIRouter, Request, HTTPException
from pydantic import BaseModel
from typing import Dict, Any
import time
from app.services.providers.registry import ProviderRegistry
from app.services.providers.discovery import discover_all_models
from app.services.providers.strategy import choose_provider_and_model
from app.utils.db import get_session
from app.utils.quality import score_quality
from app.models.provider_telemetry import ProviderTelemetry
from app.models.learning_profile import LearningProfile
from app.models.conversation import Conversation
from app.models.message import Message

router = APIRouter(prefix="/api/compare", tags=["compare"])

class CompareIn(BaseModel):
    prompt: str
    task: str = "long_form"
    values: Dict[str, float] = {"speed":0.34,"accuracy":0.33,"cost":0.33}

@router.post("")
async def compare(request: Request, body: CompareIn):
    uid = request.session.get("user_id")
    if not uid: raise HTTPException(401, "Sign in required")
    registry = ProviderRegistry(); models = await discover_all_models(registry)
    # pick two providers (top 2 by available order for MVP)
    names = list(models.keys())[:2]
    outs = []
    for name in names:
        model = models[name][0] if models.get(name) else None
        prov = registry.get(name)
        t0=time.time(); res = await prov.complete(body.prompt, task=body.task, values=body.values, model=model); t1=time.time()
        outs.append({"provider": name, "model": model or res.model, "text": res.text or "", "latency_ms": (t1-t0)*1000.0})
    return {"a": outs[0], "b": outs[1]}

class ChooseIn(BaseModel):
    winner: str
    a: Dict[str, Any]
    b: Dict[str, Any]

@router.post("/choose")
async def choose(request: Request, body: ChooseIn):
    uid = request.session.get("user_id")
    if not uid: raise HTTPException(401, "Sign in required")
    win = body.a if body.winner == "A" else body.b
    lose = body.b if body.winner == "A" else body.a
    # record telemetry and small learning boost for winner
    with get_session() as session:
        pt = ProviderTelemetry(user_id=uid, provider=win["provider"], model=win["model"], task="long_form", latency_ms=win.get("latency_ms",0.0), success=True, failover_used=False, quality_overall=0.0)
        session.add(pt)
        # learning boost
        from app.models.learning_profile import LearningProfile
        lp = session.exec(LearningProfile.select().where(LearningProfile.provider==win["provider"], LearningProfile.model==win["model"], LearningProfile.task=="long_form")).first()  # type: ignore
        if not lp:
            lp = LearningProfile(workspace_id=None, provider=win["provider"], model=win["model"], task="long_form", bias=0.0)
        lp.bias = min(0.15, lp.bias + 0.02)
        session.add(lp); session.commit()
    return {"ok": True}
