
from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Depends
from app.utils.realtime import manager
from typing import Optional

router = APIRouter()

@router.websocket("/ws/trails/{conversation_id}")
async def ws_trails(ws: WebSocket, conversation_id: int, user: Optional[str] = None):
    # user is optional query param for display
    await manager.connect(conversation_id, ws)
    try:
        await manager.broadcast(conversation_id, {"type":"presence","user": user or "anon", "status":"join"})
        while True:
            data = await ws.receive_json()
            # data: {"type": "typing"|"message", ...}
            await manager.broadcast(conversation_id, data)
    except WebSocketDisconnect:
        await manager.disconnect(conversation_id, ws)
        await manager.broadcast(conversation_id, {"type":"presence","user": user or "anon", "status":"leave"})
