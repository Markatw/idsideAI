
from fastapi import APIRouter, Request, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from urllib.parse import urlencode
from app.utils.db import get_session
from app.models.user import User
from app.models.workspace import Workspace
from app.models.membership import Membership
from app.models.invite import Invite
from app.models.onboarding_selection import OnboardingSelection
from app.utils.invite import make_invite_token, verify_invite_token, dev_send_invite
from app.utils.permissions import current_role, can_invite

router = APIRouter(prefix="/collab", tags=["collaboration"])
templates = Jinja2Templates(directory="app/templates")

def _get_current_workspace(session, user_id: int):
    # Simple heuristic: latest workspace where user is owner
    mem = session.exec(Membership.select().where(Membership.user_id==user_id)).first()  # type: ignore
    if not mem:
        return None
    ws = session.get(Workspace, mem.workspace_id)
    return ws

@router.get("", response_class=HTMLResponse)
async def collab_home(request: Request):
    if not request.session.get('user_id'):
        return RedirectResponse(url='/auth/signin', status_code=303)
    uid = request.session['user_id']
    with get_session() as session:
        ws = _get_current_workspace(session, uid)
        if not ws:
            return RedirectResponse(url='/onboarding', status_code=303)
        # members
        members = session.exec(Membership.select().where(Membership.workspace_id==ws.id)).all()  # type: ignore
        users = {u.id: u for u in session.exec(User.select()).all()}  # naive join
        invites = session.exec(Invite.select().where(Invite.workspace_id==ws.id)).all()  # type: ignore
        # owner turbo status
        owner = session.exec(Membership.select().where(Membership.workspace_id==ws.id, Membership.role=="owner")).first()  # type: ignore
        has_turbo = False
        if owner:
            ob = session.exec(OnboardingSelection.select().where(OnboardingSelection.user_id==owner.user_id)).first()  # type: ignore
            has_turbo = bool(ob and ob.turbo_opt_in)
        return templates.TemplateResponse("collab.html", {"request": request, "ws": ws, "members": members, "users": users, "invites": invites, "turbo": has_turbo})

@router.post("/invite")
async def send_invite(request: Request, email: str = Form(...), role: str = Form("member")):
    if not request.session.get('user_id'):
        return RedirectResponse(url='/auth/signin', status_code=303)
    uid = request.session['user_id']
    with get_session() as session:
        ws = _get_current_workspace(session, uid)
        if not ws:
            return RedirectResponse(url='/onboarding', status_code=303)
        # permission check
        role_me = current_role(uid, ws.id)
        if not can_invite(role_me):
            return RedirectResponse(url='/collab', status_code=303)
        tok = make_invite_token(email=email, workspace_id=ws.id, role=role)
        inv = Invite(workspace_id=ws.id, email=email, role=role, token=tok, status="pending")
        session.add(inv); session.commit()
        base = str(request.base_url).rstrip("/")
        link = f"{base}/collab/accept?{urlencode({'token': tok})}"
        dev_send_invite(email, link)
    return RedirectResponse(url="/collab", status_code=303)

@router.get("/accept")
async def accept_invite(request: Request, token: str):
    data = verify_invite_token(token)
    if not data:
        return templates.TemplateResponse("collab_accept.html", {"request": request, "ok": False, "msg": "Invalid or expired invite."})
    email = data["email"]; ws_id = int(data["workspace_id"]); role = data.get("role","member")
    with get_session() as session:
        # ensure user exists
        user = session.exec(User.select().where(User.email==email)).first()  # type: ignore
        if not user:
            user = User(email=email); session.add(user); session.commit(); session.refresh(user)
        # sign them in
        request.session["user_id"] = user.id
        request.session["email"] = user.email
        # add membership if not present
        mem = session.exec(Membership.select().where(Membership.user_id==user.id, Membership.workspace_id==ws_id)).first()  # type: ignore
        if not mem:
            mem = Membership(user_id=user.id, workspace_id=ws_id, role=role)
            session.add(mem)
        # mark invite accepted
        inv = session.exec(Invite.select().where(Invite.token==token)).first()  # type: ignore
        if inv:
            inv.status = "accepted"; session.add(inv)
        session.commit()
    return templates.TemplateResponse("collab_accept.html", {"request": request, "ok": True, "msg": "You're in! Redirecting to dashboard...", "redirect": "/dashboard"})

@router.get("/decline")
async def decline_invite(request: Request, token: str):
    with get_session() as session:
        inv = session.exec(Invite.select().where(Invite.token==token)).first()  # type: ignore
        if inv:
            inv.status = "declined"; session.add(inv); session.commit()
    return templates.TemplateResponse("collab_accept.html", {"request": request, "ok": True, "msg": "Invite declined."})
