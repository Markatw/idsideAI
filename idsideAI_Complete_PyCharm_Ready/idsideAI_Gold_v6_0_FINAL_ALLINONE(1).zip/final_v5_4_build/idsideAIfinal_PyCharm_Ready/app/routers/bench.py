
from fastapi import APIRouter, Request, HTTPException
from typing import Dict, Any
import time
from app.services.providers.registry import ProviderRegistry
from app.services.providers.discovery import discover_all_models
from app.services.providers.strategy import choose_provider_and_model
from app.utils.db import get_session
from app.models.provider_telemetry import ProviderTelemetry
from app.models.membership import Membership

router = APIRouter(prefix="/api/bench", tags=["benchmark"])

# Micro prompt used for pings per task
MICRO = {
    "long_form": "Write a single sentence about the moon.",
    "code": "In one sentence, say what Python is.",
    "search_qa": "Answer in 5 words: capital of France?",
    "cheap_fast": "Reply 'ok'.",
    "classification": "Classify: cat or dog? 'cat'"
}

@router.post("/run")
async def run_benchmark(request: Request, task: str = "long_form"):
    uid = request.session.get("user_id")
    if not uid:
        raise HTTPException(401, "Sign in required")
    registry = ProviderRegistry()
    models = await discover_all_models(registry)
    # try top 3 providers for task based on discovery; for MVP, just first 3 available
    tested = []
    for name in list(models.keys())[:3]:
        prov = registry.get(name)
        model = models[name][0] if models.get(name) else None
        if not prov or not model:
            continue
        t0 = time.time()
        try:
            res = await prov.complete(MICRO.get(task, MICRO["long_form"]), task=task, values={"speed":0.5,"accuracy":0.5,"cost":0.5}, model=model)
            ok = True
        except Exception:
            ok = False
            res = type("R",(),{"text":""})()
        t1 = time.time()
        latency = (t1-t0)*1000.0
        with get_session() as session:
            mem = session.exec(Membership.select().where(Membership.user_id==uid)).first()  # type: ignore
            pt = ProviderTelemetry(workspace_id=mem.workspace_id if mem else None, user_id=uid, provider=name, model=model, task=task, latency_ms=latency, success=ok, failover_used=False, quality_overall=0.0)
            session.add(pt); session.commit()
        tested.append({"provider": name, "model": model, "latency_ms": latency, "success": ok})
    return {"tested": tested}

@router.get("/recommend")
async def recommend(request: Request, task: str = "long_form"):
    uid = request.session.get("user_id")
    if not uid:
        raise HTTPException(401, "Sign in required")
    wid = request.session.get("workspace_id")
    # combine last 24h telemetry (success/speed) to pick best
    with get_session() as session:
        rows = session.exec(ProviderTelemetry.select().where(ProviderTelemetry.workspace_id==wid, ProviderTelemetry.task==task).order_by(ProviderTelemetry.id.desc())).all()  # type: ignore
        if not rows:
            return {"provider": None, "model": None, "reason": "no data"}
        scores = {}
        for r in rows[:200]:
            key = (r.provider, r.model)
            s = scores.get(key, {"count":0,"ok":0,"lat":0.0})
            s["count"] += 1; s["ok"] += int(r.success); s["lat"] += r.latency_ms
            scores[key] = s
        best = None; best_score = -1.0
        for (prov, model), s in scores.items():
            ok_rate = s["ok"]/s["count"]
            avg_lat = (s["lat"]/s["count"]) or 1.0
            sc = ok_rate*0.8 + (1.0 - min(avg_lat/4000.0, 1.0))*0.2
            if sc > best_score:
                best_score = sc; best = {"provider": prov, "model": model, "score": sc, "ok_rate": ok_rate, "avg_ms": avg_lat}
    return best or {"provider": None, "model": None}
