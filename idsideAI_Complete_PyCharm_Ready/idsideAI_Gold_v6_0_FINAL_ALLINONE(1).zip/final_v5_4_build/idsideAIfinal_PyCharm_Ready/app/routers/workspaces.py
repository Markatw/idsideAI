
from fastapi import APIRouter, Request, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from app.utils.db import get_session
from app.models.workspace import Workspace
from app.models.membership import Membership

router = APIRouter(prefix="/workspaces", tags=["workspaces"])
templates = Jinja2Templates(directory="app/templates")

@router.get("", response_class=HTMLResponse)
async def list_workspaces(request: Request):
    if not request.session.get('user_id'):
        return RedirectResponse(url='/auth/signin', status_code=303)
    uid = request.session['user_id']
    with get_session() as session:
        memberships = session.exec(Membership.select().where(Membership.user_id==uid)).all()  # type: ignore
        ws_ids = [m.workspace_id for m in memberships]
        spaces = [session.get(Workspace, wid) for wid in ws_ids]
        current = request.session.get("workspace_id")
    return templates.TemplateResponse("workspaces.html", {"request": request, "spaces": spaces, "current": current})

@router.post("/new")
async def create_workspace(request: Request, name: str = Form(...)):
    if not request.session.get('user_id'):
        return RedirectResponse(url='/auth/signin', status_code=303)
    uid = request.session['user_id']
    with get_session() as session:
        ws = Workspace(kind="team", name=name or "Workspace")
        session.add(ws); session.commit(); session.refresh(ws)
        mem = Membership(user_id=uid, workspace_id=ws.id, role="owner")
        session.add(mem); session.commit()
        request.session["workspace_id"] = ws.id
    return RedirectResponse(url="/workspaces", status_code=303)

@router.post("/switch")
async def switch_workspace(request: Request, workspace_id: int = Form(...)):
    if not request.session.get('user_id'):
        return RedirectResponse(url='/auth/signin', status_code=303)
    uid = request.session['user_id']
    with get_session() as session:
        mem = session.exec(Membership.select().where(Membership.user_id==uid, Membership.workspace_id==workspace_id)).first()  # type: ignore
        if not mem:
            return RedirectResponse(url="/workspaces", status_code=303)
        request.session["workspace_id"] = workspace_id
    return RedirectResponse(url="/dashboard", status_code=303)
