from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional, Dict, Any
import time

from app.services.providers.registry import ProviderRegistry
from app.services.providers.strategy import choose_provider_and_model
from app.utils.quality import score_quality

router = APIRouter(prefix="/run", tags=["run"])

class RunIn(BaseModel):
    prompt: str
    mode: str = "standard"  # "standard" | "turbo"
    context: Optional[str] = None

@router.post("")
async def run(body: RunIn) -> Dict[str, Any]:
    if not body.prompt or not body.prompt.strip():
        raise HTTPException(400, "Prompt is required")

    registry = ProviderRegistry()
    providers = registry.available()
    if not providers:
        raise HTTPException(503, "No providers configured")

    # Strategy: for 'standard' bias to speed/cost, for 'turbo' bias to quality
    weights = {"quality": 0.4, "speed": 0.4, "cost": 0.2} if body.mode == "standard" else {"quality": 0.7, "speed": 0.2, "cost": 0.1}
    provider_name, model_name = choose_provider_and_model(task="general", constraints={"weights": weights})

    provider = registry.get(provider_name)
    if not provider:
        raise HTTPException(500, f"Provider not found: {provider_name}")

    t0 = time.time()
    result = await provider.complete(body.prompt, task="general")
    t1 = time.time()
    latency_ms = (t1 - t0) * 1000

    text = (getattr(result, "text", None) or "").strip()
    q = score_quality(body.prompt, text, latency_ms)
    return {
        "mode": body.mode,
        "provider": provider_name,
        "model": model_name,
        "latency_ms": latency_ms,
        "quality": q,
        "text": text[:8000],
    }