
from fastapi import APIRouter
from app.services.providers.registry import ProviderRegistry
from app.services.providers.discovery import discover_all_models
import asyncio

router = APIRouter(prefix="/api", tags=["api"])

@router.get("/providers")
async def providers():
    reg = ProviderRegistry()
    models = await discover_all_models(reg)
    return {
        "providers": list(reg.providers.keys()),
        "available": reg.available(),
        "models": models
    }
