
from fastapi import APIRouter, Request
from fastapi.responses import PlainTextResponse
from app.utils.db import get_session
from app.models.provider_telemetry import ProviderTelemetry
from app.models.user import User

router = APIRouter(prefix="/api/telemetry", tags=["telemetry"])

@router.get("/export")
async def export_csv(request: Request):
    uid = request.session.get("user_id")
    wid = request.session.get("workspace_id")
    if not uid: return PlainTextResponse("Unauthorized", status_code=401)
    out = ["timestamp,provider,model,task,latency_ms,success,failover_used,quality_overall,user_id,user_email"]
    with get_session() as session:
        rows = session.exec(ProviderTelemetry.select().where(ProviderTelemetry.workspace_id==wid).order_by(ProviderTelemetry.id.asc())).all()  # type: ignore
        users = {u.id: u.email for u in session.exec(User.select()).all()}
        for r in rows:
            out.append(f"{r.created_at.isoformat()},{r.provider},{r.model},{r.task},{int(r.latency_ms)},{int(r.success)},{int(r.failover_used)},{r.quality_overall},{r.user_id},{users.get(r.user_id,'')}"
            )
    return PlainTextResponse("\n".join(out), media_type="text/csv")
