from fastapi import APIRouter
router = APIRouter()
# Removed in v5.4 — Turbo is embedded in /run
