
from fastapi import APIRouter, Request, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates
from secrets import token_urlsafe
from datetime import datetime, timedelta
from app.utils.db import get_session
from app.models.conversation import Conversation
from app.models.user import User

router = APIRouter(prefix="/share", tags=["share"])
templates = Jinja2Templates(directory="app/templates")

TOKENS = {}  # in-memory for MVP; replace with table if needed

@router.post("/create")
async def create(request: Request, conversation_id: int = Form(...), expires_minutes: int = Form(60)):
    if not request.session.get('user_id'): return RedirectResponse(url='/auth/signin', status_code=303)
    tok = token_urlsafe(10)
    TOKENS[tok] = {"cid": conversation_id, "exp": datetime.utcnow() + timedelta(minutes=expires_minutes)}
    return templates.TemplateResponse("share_created.html", {"request": request, "link": f"/share/join?token={tok}"})

@router.get("/join", response_class=HTMLResponse)
async def join(request: Request, token: str):
    meta = TOKENS.get(token)
    if not meta or meta["exp"] < datetime.utcnow():
        return templates.TemplateResponse("collab_accept.html", {"request": request, "ok": False, "msg": "Link expired."})
    request.session["share_cid"] = meta["cid"]
    return RedirectResponse(url=f"/trails/view/{meta['cid']}", status_code=303)
