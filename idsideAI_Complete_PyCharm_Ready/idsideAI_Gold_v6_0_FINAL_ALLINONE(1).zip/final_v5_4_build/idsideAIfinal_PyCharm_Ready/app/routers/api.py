
from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel, Field
from typing import Optional, Dict, Any
from app.services.providers.registry import ProviderRegistry
from app.services.providers.strategy import choose_provider_and_model
from app.services.providers.discovery import discover_all_models
from app.utils.circuit_breaker import breaker
from app.utils.db import get_session
from app.models.metric import Metric
from app.models.provider_telemetry import ProviderTelemetry
from app.utils.quality import score_quality
from app.utils.confidence import compute_confidence
from app.models.conversation import Conversation
from app.models.message import Message
from app.models.membership import Membership
from app.utils.permissions import current_role, can_ask
from app.utils.optimizer import optimize_prompt
import time
from app.utils.broadcast import broadcast_assistant
from app.utils.analytics import track
import asyncio

router = APIRouter(prefix="/api", tags=["api"])

class AskInput(BaseModel):
    prompt: str = Field(min_length=1)
    task: str = Field(default="long_form")  # e.g., code | long_form | vision | search_qa | cheap_fast | classification
    values: Dict[str, float] = Field(default_factory=lambda: {"speed":0.34,"accuracy":0.33,"cost":0.33})
    preferred: Optional[str] = None  # force a provider, if desired
    conversation_id: Optional[int] = None  # attach to a conversation if provided
    optimize: Optional[bool] = False

@router.post("/ask")
async def ask(request: Request, input: AskInput):
    # Role enforcement: viewer cannot call /api/ask
    uid = request.session.get('user_id')
    wid = request.session.get('workspace_id')
    if uid and not can_ask(current_role(uid, wid)):
        from fastapi import HTTPException
        raise HTTPException(status_code=403, detail="Viewer cannot perform Ask")
    
    registry = ProviderRegistry()
    if input.preferred:
        prov = registry.get(input.preferred)
        if not prov:
            raise HTTPException(400, f"Unknown provider '{input.preferred}'")
        res = await prov.complete(input.prompt, task=input.task, values=input.values)
        return {"text": res.text, "provider": res.provider, "model": res.model, "meta": res.meta, "selected": input.preferred, "available_providers": registry.available()}

    models = await discover_all_models(registry)
    name, model, meta = choose_provider_and_model(input.task, input.values, registry, models)
    prov = registry.get(name)
    if not prov:
        raise HTTPException(500, "No provider available")
    try:
        res = await prov.complete(input.prompt, task=input.task, values=input.values, model=model)
        breaker.record_success(name)
        request.session['last_selection'] = {"provider": name, "model": model}
        return {"text": res.text, "provider": res.provider, "model": model or res.model, "meta": res.meta, "selected": name, "score": meta.get("score"), "available_providers": registry.available()}
    except Exception as e:
        breaker.record_failure(name)
        # simple failover: try once more with next best by closing this provider temporarily
        # mark open circuit and re-run selection without this provider
        models = await discover_all_models(registry)
        # pretend circuit is open now for this provider
        # (breaker already recorded failure; is_open will skip on next selection)
        name2, model2, meta2 = choose_provider_and_model(input.task, input.values, registry, models)
        prov2 = registry.get(name2)
        res2 = await prov2.complete(input.prompt, task=input.task, values=input.values, model=model2)
        breaker.record_success(name2)
        request.session['last_selection'] = {"provider": name2, "model": model2}
        return {"text": res2.text, "provider": res2.provider, "model": model2 or res2.model, "meta": res2.meta, "selected": name2, "failover_from": name, "available_providers": registry.available()}


@router.post("/ask/pastbest")
async def ask_pastbest(request: Request, input: AskInput):
    # Use telemetry to choose historically best performer for task
    uid = request.session.get('user_id'); wid = request.session.get('workspace_id')
    if uid is None:
        raise HTTPException(status_code=401, detail="Sign in required")
    from app.models.provider_telemetry import ProviderTelemetry
    best = None; best_score = -1.0
    with get_session() as session:
        rows = session.exec(ProviderTelemetry.select().where(ProviderTelemetry.workspace_id==wid)).all()  # type: ignore
        for r in rows:
            score = (1.0 if r.success else 0.0) * 0.8 + (1.0 - min(r.latency_ms/5000.0,1.0)) * 0.2
            key = (r.provider, r.model)
            if score > best_score:
                best_score = score; best = key
    if not best:
        # Fallback to normal ask
        return await ask(request, input)
    # Force preferred provider and model
    input.preferred = best[0]
    input.model = best[1]
    return await ask(request, input)
