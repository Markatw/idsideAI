
from fastapi import APIRouter
from app.utils.circuit_breaker import state

router = APIRouter(prefix="/api/status", tags=["status"])

@router.get("/breaker")
async def breaker_status():
    return state()


from fastapi import Request
from fastapi.responses import HTMLResponse
from datetime import datetime, timedelta
from app.utils.db import get_session
from app.models.provider_telemetry import ProviderTelemetry
from app.utils.circuit_breaker import state as breaker_state
from fastapi.templating import Jinja2Templates
templates = Jinja2Templates(directory="app/templates")

@router.get("/providers", response_class=HTMLResponse)
async def providers_status(request: Request):
    with get_session() as session:
        since_24h = datetime.utcnow() - timedelta(hours=24)
        rows = session.exec(ProviderTelemetry.select().where(ProviderTelemetry.created_at >= since_24h)).all()  # type: ignore
        stats = {}
        for r in rows:
            s = stats.get(r.provider, {"count":0,"ok":0,"lat":0.0})
            s["count"] += 1; s["ok"] += int(r.success); s["lat"] += r.latency_ms
            stats[r.provider] = s
        for k,v in stats.items():
            v["uptime"] = round(100.0 * v["ok"]/max(1,v["count"]), 1)
            v["avg_ms"] = int(v["lat"]/max(1,v["count"]))
        br = breaker_state()
    return templates.TemplateResponse("providers_status.html", {"request": request, "stats": stats, "breaker": br})
