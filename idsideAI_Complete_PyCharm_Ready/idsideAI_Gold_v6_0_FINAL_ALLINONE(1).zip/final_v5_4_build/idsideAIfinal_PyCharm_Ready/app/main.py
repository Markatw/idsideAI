
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from starlette.middleware.sessions import SessionMiddleware
from app.routers import core, onboarding, dashboard
from app.routers import api
from app.routers import share as share_router
from app.routers import settings as settings_router

from app.routers import decision_models
from app.utils.db import init_db
from app.utils.security_headers import SecurityHeadersMiddleware
from app.utils.plan_enforcement import PlanEnforcementMiddleware
import os
from app.utils.logging import configure_logging
from app.utils.request_log import RequestLogMiddleware
configure_logging()

app = FastAPI(title="idsideAI", version="0.2.0", docs_url="/docs", redoc_url="/redoc")

# Sessions (needed for a simple user placeholder until auth is added)
app.add_middleware(SessionMiddleware, secret_key=os.getenv("SECRET_KEY","dev-secret-change-me"), same_site='lax', https_only=os.getenv('SECURE_COOKIES','false').lower() in ('1','true','yes'))
app.add_middleware(SecurityHeadersMiddleware)
app.add_middleware(RequestLogMiddleware)
app.add_middleware(CORSMiddleware, allow_origins=os.getenv('ALLOWED_ORIGINS','').split(',') if os.getenv('ALLOWED_ORIGINS') else [], allow_credentials=True, allow_methods=['GET','POST'], allow_headers=['Content-Type'])
app.add_middleware(PlanEnforcementMiddleware)

# Initialize DB
init_db()

# Mount static files
app.mount("/static", StaticFiles(directory="app/static"), name="static")

# Include routers
app.include_router(core.router)
app.include_router(onboarding.router)
app.include_router(dashboard.router)
app.include_router(api.router)
app.include_router(share_router.router)
app.include_router(settings_router.router)
app.include_router(turbo_taster.router)
app.include_router(decision_models.router)

# Health check
@app.get("/healthz")
async def healthz():
    return {"status": "ok", "app": "idsideAI", "version": "0.2.0"}


# --- idsideAI v5.3 patch: include run router ---
try:
    from app.routers import run as run_router
    app.include_router(run_router.router)
except Exception as _e:
    # Safe-guard to avoid boot failure if missing deps
    pass

from app.routers import telemetry_ui as telemetry_ui_router
app.include_router(telemetry_ui_router.router)
