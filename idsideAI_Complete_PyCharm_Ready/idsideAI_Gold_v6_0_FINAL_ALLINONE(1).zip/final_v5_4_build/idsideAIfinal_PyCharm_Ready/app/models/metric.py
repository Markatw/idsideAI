
from typing import Optional
from datetime import datetime
from sqlmodel import SQLModel, Field

class Metric(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    user_id: int = Field(foreign_key="user.id")
    ts: datetime = Field(default_factory=datetime.utcnow)
    accuracy: float = 0.0
    completeness: float = 0.0
    adherence: float = 0.0
    speed: float = 0.0
