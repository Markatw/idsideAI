
from typing import Optional
from sqlmodel import SQLModel, Field

class TopUpBalance(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    # scope: per-user or per-workspace depending on quota mode
    user_id: Optional[int] = None
    workspace_id: Optional[int] = None
    remaining: int = 0
