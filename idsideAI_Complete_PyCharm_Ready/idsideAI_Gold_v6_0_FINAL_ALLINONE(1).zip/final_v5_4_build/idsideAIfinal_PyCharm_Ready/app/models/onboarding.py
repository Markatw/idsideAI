
from pydantic import BaseModel, Field
from typing import List

class OnboardingInput(BaseModel):
    plan: str = Field(description="free | paid | paid_turbo")
    workspace: str = Field(description="solo | team | family | education | research")
    collaborators: List[str] = Field(default_factory=list)
    turbo_opt_in: bool = False
