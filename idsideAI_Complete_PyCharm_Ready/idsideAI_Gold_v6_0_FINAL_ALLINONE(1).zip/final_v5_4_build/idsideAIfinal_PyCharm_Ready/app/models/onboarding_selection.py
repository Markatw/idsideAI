
from typing import Optional
from sqlmodel import SQLModel, Field

class OnboardingSelection(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    user_id: int = Field(foreign_key="user.id")
    plan: str  # free | paid | paid_turbo
    turbo_opt_in: bool = False
