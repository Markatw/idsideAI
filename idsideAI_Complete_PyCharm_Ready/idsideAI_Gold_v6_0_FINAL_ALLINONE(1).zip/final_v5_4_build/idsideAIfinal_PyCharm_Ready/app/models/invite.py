
from typing import Optional
from datetime import datetime, timedelta
from sqlmodel import SQLModel, Field

class Invite(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    workspace_id: int = Field(foreign_key="workspace.id")
    email: str
    role: str = "member"  # member | admin (future)
    status: str = "pending"  # pending | accepted | declined | expired
    token: str
    created_at: datetime = Field(default_factory=datetime.utcnow)
    expires_at: datetime = Field(default_factory=lambda: datetime.utcnow() + timedelta(days=7))
