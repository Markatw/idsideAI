
from typing import Optional
from sqlmodel import SQLModel, Field

class ReferralLink(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    owner_user_id: int = Field(foreign_key="user.id")
    code: str = Field(index=True, unique=True)
    donate: bool = False  # whether owner donates credits to social pool (future)
