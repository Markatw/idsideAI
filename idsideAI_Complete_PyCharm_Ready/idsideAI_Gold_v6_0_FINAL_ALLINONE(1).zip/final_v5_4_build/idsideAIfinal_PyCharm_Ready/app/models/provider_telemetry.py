
from typing import Optional
from datetime import datetime
from sqlmodel import SQLModel, Field

class ProviderTelemetry(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    workspace_id: Optional[int] = None
    user_id: Optional[int] = None
    provider: str
    model: str
    task: str
    latency_ms: float
    success: bool = True
    failover_used: bool = False
    quality_overall: float = 0.0
    created_at: datetime = Field(default_factory=datetime.utcnow)
