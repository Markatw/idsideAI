
from typing import Optional
from datetime import datetime
from sqlmodel import SQLModel, Field

class AnalyticsEvent(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    user_id: Optional[int] = None
    workspace_id: Optional[int] = None
    event: str
    meta: str = "{}"  # JSON string
    created_at: datetime = Field(default_factory=datetime.utcnow)
