
from typing import Optional
from datetime import datetime
from sqlmodel import SQLModel, Field

class LearningLog(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    workspace_id: Optional[int] = None
    user_id: Optional[int] = None
    note: str
    created_at: datetime = Field(default_factory=datetime.utcnow)
