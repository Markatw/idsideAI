
from typing import Optional
from datetime import datetime, timedelta
from sqlmodel import SQLModel, Field

class Subscription(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    user_id: int = Field(foreign_key="user.id")
    workspace_id: int = Field(foreign_key="workspace.id")
    plan: str = "free"  # free | turbo
    status: str = "inactive"  # inactive | active | canceled
    current_period_end: datetime = Field(default_factory=lambda: datetime.utcnow() + timedelta(days=30))
