
from typing import Optional
from datetime import datetime
from sqlmodel import SQLModel, Field

class Message(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    conversation_id: int = Field(foreign_key="conversation.id")
    role: str  # user | assistant
    provider: str = "unknown"
    model: str = "auto"
    content: str
    latency_ms: float = 0.0
    created_at: datetime = Field(default_factory=datetime.utcnow)
