
from typing import Optional
from datetime import date
from sqlmodel import SQLModel, Field

class RequestQuota(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    user_id: int = Field(foreign_key="user.id")
    day: date
    used: int = 0
    limit: int = 20  # free tier default
