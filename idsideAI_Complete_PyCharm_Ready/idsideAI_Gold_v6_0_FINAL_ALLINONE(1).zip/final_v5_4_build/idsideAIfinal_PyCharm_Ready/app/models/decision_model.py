from typing import Optional
from datetime import datetime
from sqlmodel import SQLModel, Field

class DecisionModel(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    user_id: Optional[int] = None
    name: str = "Untitled Decision Model"
    description: str = ""
    tags: str = "[]"
    version: int = 1
    graph_json: str = "{}"
    turbo_used: bool = False
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)