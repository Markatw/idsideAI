
import os, httpx, asyncio
from typing import Dict, Any
from .base import AIProvider, AIResponse, ProviderCapabilities

class GroqProvider(AIProvider):
    @property
    def capabilities(self) -> ProviderCapabilities:
        return ProviderCapabilities(
            name="groq",
            strengths={'speed': 0.98, 'cost': 0.7, 'code': 0.75},
            cost=0.25,
            speed=0.98,
            free_tier=True,
            context_window=32768
        )

    async def complete(self, prompt: str, **kwargs) -> AIResponse:
        import httpx
        from tenacity import retry, stop_after_attempt, wait_exponential_jitter
        model = kwargs.get("model") or "auto"
        if not self.available():
            return AIResponse(text=f"[dev-simulated groq]: " + prompt[:120], provider="groq", model=model, meta={"simulated": True})
        if model == "auto":
            model = "llama-3.1-70b-versatile"
        headers = {"Authorization": f"Bearer {self.api_key}"}
        payload = {"model": model, "messages":[{"role":"user","content": prompt}]}
        @retry(stop=stop_after_attempt(2), wait=wait_exponential_jitter(initial=0.5, max=2))
        async def _call():
            async with httpx.AsyncClient(timeout=30) as client:
                r = await client.post("https://api.groq.com/openai/v1/chat/completions", headers=headers, json=payload)
                r.raise_for_status()
                data = r.json()
                text = data["choices"][0]["message"]["content"]
                return text, data
        text, data = await _call()
        return AIResponse(text=text, provider="groq", model=model, meta={"id": data.get("id")})
