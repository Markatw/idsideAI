
from typing import Dict, List
import asyncio
from .registry import ProviderRegistry
from ...utils.model_cache import ModelCache
from ...utils.config import MODEL_CACHE_TTL_S

_cache = ModelCache(ttl_seconds=MODEL_CACHE_TTL_S)

async def discover_all_models(registry: ProviderRegistry) -> Dict[str, List[str]]:
    results: Dict[str, List[str]] = {}
    tasks = []
    names = list(registry.providers.keys())
    for n in names:
        tasks.append(_discover_one(n, registry))
    out = await asyncio.gather(*tasks)
    for name, models in out:
        results[name] = models
    return results

async def _discover_one(name: str, registry: ProviderRegistry):
    cached = _cache.get(name)
    if cached is not None:
        return name, cached
    prov = registry.get(name)
    if not prov:
        return name, []
    try:
        models = await prov.list_models()
    except Exception:
        models = []
    if not models:
        models = []  # explicit, in case of None
    _cache.set(name, models)
    return name, models
