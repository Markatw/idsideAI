
import os, httpx, asyncio
from typing import Dict, Any
from .base import AIProvider, AIResponse, ProviderCapabilities

class PerplexityProvider(AIProvider):
    @property
    def capabilities(self) -> ProviderCapabilities:
        return ProviderCapabilities(
            name="perplexity",
            strengths={'search': 0.95, 'qa': 0.9},
            cost=0.5,
            speed=0.9,
            free_tier=True,
            context_window=32768
        )

    async def complete(self, prompt: str, **kwargs) -> AIResponse:
        # If no key, simulate a response for dev so routing can be tested
        if not self.available():
            return AIResponse(
                text=f"[dev-simulated perplexity]: " + prompt[:120],
                provider="perplexity",
                model=kwargs.get("model","auto"),
                meta={"simulated": True}
            )
        # Real API call placeholder (to be filled with provider-specific endpoints)
        # For now, return a shaped response to keep the app runnable.
        return AIResponse(
            text=f"[stubbed call to perplexity] " + prompt[:120],
            provider="perplexity",
            model=kwargs.get("model","auto"),
            meta={"simulated": False}
        )

    async def list_models(self):
        # Dev: return a small sample; real impl should query provider API
        return ["auto","general","fast","cheap"]
