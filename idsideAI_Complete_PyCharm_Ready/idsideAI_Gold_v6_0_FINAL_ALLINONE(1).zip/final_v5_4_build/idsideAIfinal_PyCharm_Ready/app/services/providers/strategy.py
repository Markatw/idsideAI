
from typing import Dict, Any, List, Tuple
from .registry import ProviderRegistry
from .discovery import discover_all_models
from ...utils.config import provider_default_model, CB_FAIL_THRESHOLD, CB_COOLDOWN_SECONDS
from ...utils.circuit_breaker import breaker

from ...models.learning_profile import LearningProfile
from ...utils.db import get_session
from ...utils.turbo_config import get_turbo_config

def _learning_bias(name: str, task: str, workspace_id: int) -> float:
    # Aggregate bias across models for provider name (simple sum of top 3 models)
    from sqlmodel import select
    with get_session() as session:
        rows = session.exec(select(LearningProfile).where(LearningProfile.workspace_id==workspace_id, LearningProfile.provider==name, LearningProfile.task==task)).all()
        if not rows:
            return 0.0
        total = sum(r.bias for r in rows)
        cfg = get_turbo_config().get("learning", {})
        cap = float(cfg.get("max_total_bias", 0.15))
        if total > cap: total = cap
        if total < -cap: total = -cap
        return float(total)


# Map task to model hints (substrings). Used to rank models for each provider.
TASK_HINTS = {
    "code": ["code", "coder", "codellama", "deepseek", "mixtral"],
    "long_form": ["4o", "opus", "sonnet", "command", "mistral-large", "llama-3.1-70b"],
    "vision": ["vision", "4o", "gemini-1.5", "gpt-4o", "vision-preview"],
    "search_qa": ["r1", "pplx", "sonar", "search"],
    "cheap_fast": ["mini", "flash", "small", "turbo", "fast"],
    "classification": ["embed", "classify", "command-r"],
}

def _score_model(name: str, task: str) -> float:
    hints = TASK_HINTS.get(task, [])
    score = 0.0
    low = name.lower()
    for h in hints:
        if h in low:
            score += 1.0
    # prefer newer-looking versions (crude heuristic)
    for k in ["-1.5","-1.1","-3.1","-70b","-405b","-large"]:
        if k in low:
            score += 0.2
    return score

def _choose_model(provider: str, models: List[str], task: str, env_default: str) -> str:
    # If env default set (not 'auto') and present in list, use it
    if env_default and env_default != "auto":
        for m in models:
            if env_default in m:
                return m
    # Otherwise, pick highest scoring by task hints
    if not models:
        return env_default or "auto"
    ranked = sorted(models, key=lambda m: _score_model(m, task), reverse=True)
    return ranked[0]

def choose_provider_and_model(task: str, values: Dict[str, float], registry: ProviderRegistry, discovered: Dict[str, List[str]]) -> Tuple[str, str, Dict[str, Any]]:
    weights = { "speed": values.get("speed",0.33), "accuracy": values.get("accuracy",0.34), "cost": values.get("cost",0.33) }
    task_bias = {
        "code": {"openai": 0.9, "groq": 0.8, "mistral": 0.7},
        "long_form": {"anthropic": 0.95, "openai": 0.9, "gemini": 0.8},
        "vision": {"gemini": 0.95, "openai": 0.85},
        "search_qa": {"perplexity": 0.95, "gemini": 0.85, "openai": 0.8},
        "cheap_fast": {"groq": 0.95, "mistral": 0.85, "together": 0.8},
        "classification": {"cohere": 0.9, "openai": 0.8},
    }
    best_name, best_score = None, -1.0
    for name, prov in registry.providers.items():
        if breaker.is_open(name):
            continue  # skip temporarily open circuits
        caps = prov.capabilities
        s = (weights["speed"]*caps.speed) + (weights["accuracy"]*max(caps.strengths.values())) + (weights["cost"]*(1.0-caps.cost))
        s += task_bias.get(task, {}).get(name, 0)
        if not prov.available() and caps.free_tier:
            s += 0.1
        if s > best_score:
            best_name, best_score = name, s

    if not best_name:
        best_name = "openai"

    # Choose model for that provider
    env_default = provider_default_model(best_name)
    models = discovered.get(best_name, [])
    model = _choose_model(best_name, models, task, env_default)
    return best_name, model, {"score": best_score}
