
from __future__ import annotations
from dataclasses import dataclass
from typing import Optional, Dict, Any

@dataclass
class ProviderCapabilities:
    name: str
    strengths: Dict[str, float]  # e.g., {"long_form":0.8,"code":0.9,"vision":0.7}
    cost: float                  # relative cost score (lower is cheaper)
    speed: float                 # relative speed score (higher is faster)
    free_tier: bool              # whether a free/dev tier typically exists
    context_window: int          # tokens

@dataclass
class AIResponse:
    text: str
    provider: str
    model: str
    meta: Dict[str, Any]

class AIProvider:
    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key

    @property
    def capabilities(self) -> ProviderCapabilities:
        raise NotImplementedError

    async def complete(self, prompt: str, **kwargs) -> AIResponse:
        raise NotImplementedError

    async def list_models(self) -> list[str]:
        # Optionally overridden by concrete providers
        return []

    def available(self) -> bool:
        return bool(self.api_key)  # default: require key
