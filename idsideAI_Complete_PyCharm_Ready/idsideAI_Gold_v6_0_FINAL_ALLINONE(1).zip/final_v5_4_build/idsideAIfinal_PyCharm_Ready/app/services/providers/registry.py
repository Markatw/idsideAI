
from typing import Dict, List, Optional
import os
from .base import AIProvider
from .openai_adapter import OpenAIProvider
from .anthropic_adapter import AnthropicProvider
from .gemini_adapter import GeminiProvider
from .mistral_adapter import MistralProvider
from .cohere_adapter import CohereProvider
from .together_adapter import TogetherProvider
from .perplexity_adapter import PerplexityProvider
from .groq_adapter import GroqProvider
from .xai_adapter import XAIProvider

class ProviderRegistry:
    def __init__(self):
        # Instantiate with keys from env if present
        self.providers: Dict[str, AIProvider] = {
            "openai": OpenAIProvider(api_key=os.getenv("OPENAI_API_KEY")),
            "anthropic": AnthropicProvider(api_key=os.getenv("ANTHROPIC_API_KEY")),
            "gemini": GeminiProvider(api_key=os.getenv("GEMINI_API_KEY")),
            "mistral": MistralProvider(api_key=os.getenv("MISTRAL_API_KEY")),
            "cohere": CohereProvider(api_key=os.getenv("COHERE_API_KEY")),
            "together": TogetherProvider(api_key=os.getenv("TOGETHER_API_KEY")),
            "perplexity": PerplexityProvider(api_key=os.getenv("PPLX_API_KEY")),
            "groq": GroqProvider(api_key=os.getenv("GROQ_API_KEY")),
            "xai": XAIProvider(api_key=os.getenv("XAI_API_KEY")),
        }

    def list(self) -> List[str]:
        return list(self.providers.keys())

    def get(self, name: str) -> Optional[AIProvider]:
        return self.providers.get(name)

    def available(self) -> List[str]:
        return [n for n,p in self.providers.items() if p.available()]
