
import os, httpx, asyncio
from typing import Dict, Any
from .base import AIProvider, AIResponse, ProviderCapabilities

class OpenAIProvider(AIProvider):
    @property
    def capabilities(self) -> ProviderCapabilities:
        return ProviderCapabilities(
            name="openai",
            strengths={'long_form': 0.9, 'code': 0.9, 'vision': 0.8, 'tools': 0.9},
            cost=0.6,
            speed=0.8,
            free_tier=True,
            context_window=128000
        )

    async def complete(self, prompt: str, **kwargs) -> AIResponse:
        import httpx, asyncio
        from tenacity import retry, stop_after_attempt, wait_exponential_jitter
        model = kwargs.get("model") or "auto"
        if not self.available():
            return AIResponse(text=f"[dev-simulated openai]: " + prompt[:120], provider="openai", model=model, meta={"simulated": True})
        headers = {"Authorization": f"Bearer {self.api_key}"}
        payload = {
            "model": model if model != "auto" else "gpt-4o-mini",
            "messages": [{"role":"user","content": prompt}]
        }
        @retry(stop=stop_after_attempt(2), wait=wait_exponential_jitter(initial=0.5, max=2))
        async def _call():
            async with httpx.AsyncClient(timeout=30) as client:
                r = await client.post("https://api.openai.com/v1/chat/completions", headers=headers, json=payload)
                r.raise_for_status()
                data = r.json()
                text = data["choices"][0]["message"]["content"]
                return text, data
        text, data = await _call()
        return AIResponse(text=text, provider="openai", model=payload["model"], meta={"id": data.get("id"), "finish_reason": data["choices"][0].get("finish_reason")})
