
import os, httpx, asyncio
from typing import Dict, Any
from .base import AIProvider, AIResponse, ProviderCapabilities

class GeminiProvider(AIProvider):
    @property
    def capabilities(self) -> ProviderCapabilities:
        return ProviderCapabilities(
            name="gemini",
            strengths={'vision': 0.95, 'web': 0.85, 'multimodal': 0.9},
            cost=0.5,
            speed=0.85,
            free_tier=True,
            context_window=1000000
        )

    async def complete(self, prompt: str, **kwargs) -> AIResponse:
        import httpx
        from tenacity import retry, stop_after_attempt, wait_exponential_jitter
        key = self.api_key
        model = kwargs.get("model") or "auto"
        if not key:
            return AIResponse(text=f"[dev-simulated gemini]: " + prompt[:120], provider="gemini", model=model, meta={"simulated": True})
        if model == "auto":
            model = "gemini-1.5-flash"
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
        @retry(stop=stop_after_attempt(2), wait=wait_exponential_jitter(initial=0.5, max=2))
        async def _call():
            async with httpx.AsyncClient(timeout=30) as client:
                r = await client.post(url, params={"key": key}, json={"contents":[{"parts":[{"text": prompt}]}]})
                r.raise_for_status()
                data = r.json()
                text = data.get("candidates",[{}])[0].get("content",{}).get("parts",[{}])[0].get("text","")
                return text, data
        text, data = await _call()
        return AIResponse(text=text, provider="gemini", model=model, meta={"candidates": len(data.get("candidates", []))})
