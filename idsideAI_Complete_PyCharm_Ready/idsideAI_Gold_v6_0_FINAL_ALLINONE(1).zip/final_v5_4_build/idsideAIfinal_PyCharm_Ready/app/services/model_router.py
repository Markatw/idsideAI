
class ModelRouter:
    def route_intent(self, intent: str) -> str:
        # Stub routing logic; later add selection across providers
        return "gpt-4o"  # placeholder
