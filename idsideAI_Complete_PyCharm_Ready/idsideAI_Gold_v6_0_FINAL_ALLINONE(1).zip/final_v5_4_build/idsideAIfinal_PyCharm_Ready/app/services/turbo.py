
class TurboSummary:
    def summary(self):
        return {
            "benefits": [
                "Performance Dashboard (key quality metrics)",
                "Learning Mode (improves & persists across sessions)",
                "Quick Fix (detect & repair under-delivery)"
            ],
            "note": "You can add or remove Turbo anytime in Settings."
        }
