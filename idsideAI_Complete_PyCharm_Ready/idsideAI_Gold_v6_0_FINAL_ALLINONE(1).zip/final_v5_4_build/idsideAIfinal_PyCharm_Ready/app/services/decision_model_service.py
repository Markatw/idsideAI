import json
from typing import List, Optional
from sqlmodel import select
from app.models.decision_model import DecisionModel
from app.utils.db import get_session

def create_decision_model(name: str, description: str, tags: list, graph: dict, turbo_used: bool=False, user_id: Optional[int]=None) -> DecisionModel:
    dm = DecisionModel(
        user_id=user_id,
        name=name or "Untitled Decision Model",
        description=description or "",
        tags=json.dumps(tags or []),
        graph_json=json.dumps(graph or {}),
        turbo_used=bool(turbo_used)
    )
    with get_session() as session:
        session.add(dm)
        session.commit()
        session.refresh(dm)
        return dm

def list_decision_models(user_id: Optional[int]=None) -> List[DecisionModel]:
    with get_session() as session:
        if user_id:
            res = session.exec(select(DecisionModel).where(DecisionModel.user_id == user_id)).all()
        else:
            res = session.exec(select(DecisionModel)).all()
        return res

def get_decision_model(dm_id: int, user_id: Optional[int]=None) -> Optional[DecisionModel]:
    with get_session() as session:
        dm = session.get(DecisionModel, dm_id)
        if not dm:
            return None
        if user_id and dm.user_id and dm.user_id != user_id:
            return None
        return dm

def update_decision_model(dm_id: int, data: dict, user_id: Optional[int]=None) -> Optional[DecisionModel]:
    with get_session() as session:
        dm = session.get(DecisionModel, dm_id)
        if not dm: return None
        if user_id and dm.user_id and dm.user_id != user_id: return None
        for k in ["name","description","tags","graph_json","turbo_used","version"]:
            if k in data:
                setattr(dm, k, data[k] if k not in ["tags","graph_json"] else (data[k] if isinstance(data[k], str) else json.dumps(data[k])))
        session.add(dm); session.commit(); session.refresh(dm)
        return dm