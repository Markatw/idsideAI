
from fastapi.testclient import TestClient
from app.main import app

def test_security_headers_present():
    with TestClient(app) as c:
        r = c.get("/")
        assert "Content-Security-Policy" in r.headers
        assert "X-Content-Type-Options" in r.headers
        assert "X-Frame-Options" in r.headers
