
import os, pytest
from fastapi.testclient import TestClient
from app.main import app

@pytest.fixture(scope="module")
def client():
    os.environ["SECRET_KEY"] = "test"
    with TestClient(app) as c:
        yield c

def test_home(client):
    r = client.get("/")
    assert r.status_code == 200

def test_providers(client):
    r = client.get("/api/providers")
    assert r.status_code == 200
    data = r.json()
    assert "available" in data

def test_status_breaker(client):
    r = client.get("/api/status/breaker")
    assert r.status_code == 200
