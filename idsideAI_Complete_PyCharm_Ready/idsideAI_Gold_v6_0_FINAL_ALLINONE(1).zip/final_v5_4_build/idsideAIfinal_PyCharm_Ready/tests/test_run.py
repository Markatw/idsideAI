from fastapi.testclient import TestClient
from app.main import app
from app.utils.db import init_db

def test_run_standard_basic():
    init_db()
    c = TestClient(app)
    r = c.post("/run", json={"prompt":"Say hello","mode":"standard"})
    assert r.status_code == 200, r.text
    j = r.json()
    assert j["mode"] == "standard"
    assert "provider" in j and "latency_ms" in j

def test_run_turbo_basic():
    init_db()
    c = TestClient(app)
    r = c.post("/run", json={"prompt":"Explain gravity in 2 lines","mode":"turbo"})
    assert r.status_code == 200, r.text
    j = r.json()
    assert j["mode"] == "turbo"
    assert "provider" in j and "quality" in j